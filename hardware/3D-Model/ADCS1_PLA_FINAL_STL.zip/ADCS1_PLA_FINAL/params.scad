// ADCS-1 reaction wheel demonstrator. PARAMETERS. All lengths mm, masses g.
// Tags: MEASURED = you measured it. DRAFT NOT MEASURED = estimate, confirm before printing.
// Coordinates: origin on the bearing axis, x right, y up. z = 0 is the TOP surface of the platform plate.
// Everything stays DRAFT NOT MEASURED until you confirm it.
// REV 2 (audit): arch re-made as a support-free prism, flywheel re-made hub-down with an open set-screw channel, wheel cover added.

// ---------------- bearing (4 inch square lazy susan)
B_W        = 96;     // MEASURED   plate size
B_T        = 8;      // MEASURED   total thickness
B_OPEN_D   = 51;     // DRAFT NOT MEASURED  clear opening (51 vs 55 measured twice, using the smaller)
B_HOLE_D   = 3.7;    // DRAFT NOT MEASURED  corner hole diameter
B_HOLE_P   = 41;     // DRAFT NOT MEASURED  holes at (+-41,+-41), 82 mm square
B_TOP_M    = 55;     // DRAFT NOT MEASURED  top plate mass (g)
SP_H       = 4;      // DRAFT NOT MEASURED  spacer height, check against raised ring and screw heads
SP_W       = 11;     // spacer footprint

// ---------------- fasteners (M3)
M3_CLR     = 3.5;    // clearance hole
M3_NUT_AF  = 5.5;    // MEASURE on your nuts
M3_NUT_T   = 2.4;
NUT_SLACK  = 0.4;    // added to nut width for pockets (wide tolerance)
NUT_POCKET = 2.8;    // pocket depth
M3_HEAD_D  = 5.8;    // pan head
M3_HEAD_H  = 2.6;

// ---------------- platform
PL_X       = 160;    // outline, set by layout search
PL_Y       = 134;
PL_T       = 3;      // plate thickness
PL_R       = 6;      // corner radius
BOSS_H     = 1.5;    // raised pads above z=0 at screw points
BOSS_W     = 11;
RIM_H      = 2.5;    // module pocket rim height
RIM_W      = 1.2;
CL         = 0.8;    // module pocket clearance per side (wide tolerance)
EDGE_OPEN  = 1;

// ---------------- electronics, pockets on the platform
// [name, x, y, w, h, height, mass_g, open_side]   (w x h are the footprint as placed)
PCOMPS = [
  ["NANO",   19.5,  44.9, 17.8, 43.2, 10, 7, "+y"],
  ["NRF",    58.4,  47.4, 15.2, 29.0, 12, 2, "+y"],
  ["MPU",    -1.4,  48.6, 16.4, 21.2, 10, 2, ""],
  ["DRV",   -24.1,  34.9, 21.0, 19.0,  9, 3, ""],
  ["BUCK",   54.8,  -2.3, 26.0, 43.0, 14, 12, ""],
  ["PERF",   57.0, -46.4, 20.0, 30.0,  8, 4, ""],
  ["FUSE",  -53.0,  -0.8, 12.0, 20.0,  8, 4, ""],
  ["SW",      2.5, -55.5, 16.0, 22.0, 15, 3, "-y"],
  ["LEVEL", -19.5, -48.3, 25.0, 25.0,  6, 2, ""]
];

// ---------------- battery (2 cell holder, centred on the axis, long side along x)
BAT_W      = 77;     // DRAFT NOT MEASURED  along x
BAT_D      = 40;     // DRAFT NOT MEASURED  along y
BAT_H      = 21;     // DRAFT NOT MEASURED
M_BATT     = 105;    // holder plus two cells
BAT_END_WALL = 3;    // low end stops on the platform
BAT_END_H    = 5;

// ---------------- battery hold-down bars + cable ties
RB_X       = 33.5;   // bar centres at x = +-RB_X
RB_L       = 43;     // along y
RB_W       = 8;      // along x
RB_T       = 3;
TIE_Y      = 22.5;   // tie slots at y = +-TIE_Y
TIE_SLOT_X = 4.2;
TIE_SLOT_Y = 1.8;
TIE_GROOVE = 3.8;

// ---------------- motor (N20, 12x10 body) and arch
MOT_W      = 12;     // DRAFT NOT MEASURED  across x
MOT_D      = 10;     // DRAFT NOT MEASURED  across y
MOT_L      = 25;     // DRAFT NOT MEASURED  body 15 + gearbox 10
MOT_SHAFT  = 9.5;    // DRAFT NOT MEASURED  exposed shaft above the collar
MOT_SHAFT_D= 3;      // 3 mm D shaft
MOT_FLAT   = 2.5;    // D flat across (DRAFT NOT MEASURED)
M_MOTOR    = 10;
ARCH_GAP   = 2.5;    // clearance above the holder
ARCH_T     = 4;
ARCH_UNDER = BAT_H + ARCH_GAP;
LEG_X      = 14;     // leg width along x
LEG_Y      = 5;      // leg thickness
LEG_IN     = BAT_D/2 + 1.8;      // inner face at y = +-LEG_IN
FOOT_Y     = 8;
FOOT_T     = 5.5;    // foot thickness (screw head recess is cut into the top)
HEAD_REC   = 3.0;    // screw head recess depth (head is 2.6)
FOOT_SCREW_Y = LEG_IN + LEG_Y + FOOT_Y/2;   // screw at y=+-30.8
ARCH_W     = 16;     // arch width along x. ALL arch parts share one flat face so it prints on its side with no supports
FOOT_X0    = -7;     // foot spans x = FOOT_X0 .. +ARCH_W/2 (keeps 0.65 mm off the nearest platform rim)
SOCK_X     = 16;     // = ARCH_W
SOCK_YM    = 8;      // socket outer y toward -y
SOCK_YP    = 14.8;   // socket outer y toward +y (clamp ear). Was 10.5: the nut pocket broke through the wall
CLAMP_Y    = 10.2;   // clamp screw y position
SLIT       = 1.6;    // clamp slit width (prints as a short bridge)
SOCK_H     = 14;

// ---------------- flywheel (8 steel M8 nuts)
NUT_AF     = 13;     // M8 nut across flats, MEASURE
NUT_TH     = 6.5;    // M8 nut thickness, MEASURE
NUT_M      = 5.5;    // M8 nut mass, DRAFT NOT MEASURED
N_NUTS     = 8;
WH_RING_R  = 24.5;   // nut centre radius
WH_R       = 34.2;
WH_T       = 8;
WH_HUB_D   = 18;
WH_HUB_H   = 14;    // hub height in the PRINT orientation (disc on the bed, hub up)
SCREW_ABOVE_DISC = 2.5; // set screw axis height above the disc face, so the screw sits in the hub, not inside the disc
CH_W       = 3.6;    // open-top set screw channel width
COVER_D    = 66;     // optional pocket cover disc
COVER_T    = 1.0;
COVER_HOLE = 19.2;
WH_POCKET  = 13.6;   // hex pocket AF
WH_FLOOR   = 1.2;
SHAFT_CLR  = 0.35;   // added to the D bore (wide tolerance)

// ---------------- base
BASE_X     = 120;
BASE_Y     = 120;
BASE_T     = 6;
BASE_R     = 8;
BASE_RECESS= 96.8;   // locating recess for the bearing
BASE_RECESS_D = 1.2;

// ---------------- balance aids
BAL_X      = -70.5;  // ballast bay, placed to zero the estimated CoM (re-solve after weighing parts)
BAL_Y      = -11.8;
BAL_G      = 14.6;   // target ballast mass
BAL_W      = 14;
TRIM_D     = 10;
TRIM_DEPTH = 1.2;
TRIM_X     = 74.5;
TRIM_Y     = 60.5;

// ---------------- masses not in PCOMPS
M_WIRES    = 20;
M_LEVEL_EXTRA = 0;

// ---------------- derived
function hexd(af) = af / cos(30);
module hex_prism(af, h){ cylinder(d=hexd(af), h=h, $fn=6); }
module rrect(x, y, r){ offset(r=r) square([x-2*r, y-2*r], center=true); }
// z of motor base, shaft tip, wheel bottom
MOT_Z0     = ARCH_UNDER + ARCH_T;
MOT_TOP    = MOT_Z0 + MOT_L;
WH_Z0      = MOT_TOP + 1.5;
