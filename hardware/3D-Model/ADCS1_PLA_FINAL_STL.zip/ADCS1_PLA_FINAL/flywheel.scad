// flywheel.scad  REV 2.  DRAFT NOT MEASURED. Eight steel M8 nuts in hex pockets.
// PRINT ORIENTATION: disc flat on the bed, pockets UP, hub UP, no supports (this is the orientation of PRINT=true).
// MOUNTED UPSIDE DOWN: hub points down onto the motor shaft, pockets face down (see assembly.scad). Glue the nuts in while
// the wheel is still lying pockets-up, then fit wheel_cover.stl over the pockets so the nuts cannot fall out.
// The M3 set screw lies in an OPEN-TOP channel in the hub above the disc, so it can be inserted, found and turned with a hex key.
PRINT = false;
include <params.scad>
module d_hole(h){
  // round bore with one flat (flat faces -y), oversize for single-print tolerance
  d = MOT_SHAFT_D + SHAFT_CLR;
  flat = MOT_FLAT + SHAFT_CLR;
  intersection(){
    cylinder(d=d, h=h, $fn=48);
    translate([-d, d/2 - flat, 0]) cube([2*d, 2*d, h]);
  }
}
module flywheel(){
  zs = WH_T + SCREW_ABOVE_DISC;                 // set screw axis height (print frame)
  nw = M3_NUT_AF + NUT_SLACK + 0.4;             // nut slot width (x)
  nd = M3_NUT_T + 0.4;                          // nut slot depth (y)
  ny0 = 2.5;                                    // nut slot inner face, distance from the axis
  difference(){
    union(){
      cylinder(r=WH_R, h=WH_T, $fn=120);
      translate([0,0,0.5]) cylinder(d=WH_HUB_D, h=WH_HUB_H-0.5, $fn=60);
    }
    // eight nut pockets, open upward, 1.2 mm floor
    for (i=[0:N_NUTS-1]) rotate(i*360/N_NUTS) translate([WH_RING_R, 0, WH_T-NUT_TH-0.3]) rotate(30) hex_prism(WH_POCKET, NUT_TH+1);
    // D bore through
    translate([0,0,-1]) d_hole(WH_HUB_H+2);
    // set screw channel, open to the top, from the bore flat out through the hub wall on the -y (flat) side
    translate([-CH_W/2, -(WH_HUB_D/2+1), zs-1.8]) cube([CH_W, WH_HUB_D/2+1-0.9, WH_HUB_H+1-(zs-1.8)]);
    // captive M3 nut slot, open to the top
    translate([-nw/2, -(ny0+nd), zs-3.5]) cube([nw, nd, WH_HUB_H+1-(zs-3.5)]);
  }
}
// mounted: hub down, hub end WH_Z0 above the platform top
module flywheel_placed(){ translate([0,0,WH_Z0+WH_HUB_H]) rotate([180,0,0]) flywheel(); }
if (PRINT) flywheel(); else flywheel_placed();
