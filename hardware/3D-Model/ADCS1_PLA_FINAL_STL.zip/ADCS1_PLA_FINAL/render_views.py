"""Renders from the FINAL placed STLs (matplotlib, painter's algorithm). Writes assembly_view.png, assembly_top.png, assembly_side.png,
assembly_exploded.png, flywheel_closeup.png, flywheel_section.png"""
import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from meshlib import load_stl, raster_fill
from pyparams import load
P = load(); L = lambda n, d='stl/placed': load_stl(f'{d}/{n}.stl')
def boxtri(x0, x1, y0, y1, z0, z1):
    v = np.array([[x, y, z] for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]); q = [(0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3)]
    T = []
    for a, b, c, d in q: T += [[v[a], v[b], v[c]], [v[a], v[c], v[d]]]
    return np.array(T)
def dummies():
    out = []
    for c in P['COMPS']: out.append((boxtri(c['x']-c['w']/2, c['x']+c['w']/2, c['y']-c['h']/2, c['y']+c['h']/2, 0, c['ht']), '#2e8b57', 'modules'))
    out.append((boxtri(-P['BAT_W']/2, P['BAT_W']/2, -P['BAT_D']/2, P['BAT_D']/2, 0, P['BAT_H']), '#d4a017', 'holder'))
    out.append((boxtri(-P['MOT_W']/2, P['MOT_W']/2, -P['MOT_D']/2, P['MOT_D']/2, P['MOT_Z0'], P['MOT_TOP']), '#555555', 'motor'))
    zt = -P['PL_T'] - P['SP_H']; out.append((boxtri(-48, 48, -48, 48, zt - P['B_T'], zt), '#b8b8c0', 'bearing'))
    return out
COL = dict(platform='#3b8ea5', base='#2f6f80', spacer='#e07a5f', battery_retainer='#f2cc8f', motor_mount='#5b7db1', flywheel='#c9503c', wheel_cover='#e9a89b')
def draw(ax, items, elev, azim, lim=None):
    light = np.array([0.4, -0.5, 0.8]); light /= np.linalg.norm(light)
    polys = []; cols = []
    for T, c, _ in items:
        n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]); n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-12
        sh = 0.45 + 0.55 * np.clip(n @ light, 0, 1); base = np.array(matplotlib.colors.to_rgb(c))
        polys.append(T); cols.append(np.clip(base[None] * sh[:, None], 0, 1))
    pc = Poly3DCollection(np.concatenate(polys), facecolors=np.concatenate(cols), edgecolor='none'); ax.add_collection3d(pc)
    allp = np.concatenate(polys).reshape(-1, 3); mn, mx = allp.min(0), allp.max(0); c = (mn + mx) / 2; r = (mx - mn).max() / 2 if lim is None else lim
    ax.set_xlim(c[0]-r, c[0]+r); ax.set_ylim(c[1]-r, c[1]+r); ax.set_zlim(c[2]-r, c[2]+r); ax.set_box_aspect((1, 1, 1)); ax.view_init(elev, azim); ax.set_axis_off()
def assembly(shift=None):
    S = shift or {}
    parts = [(L(n), COL[n], n) for n in COL]
    out = []
    for T, c, n in parts:
        T = T.copy(); T[:, :, 2] += S.get(n, 0); out.append((T, c, n))
    for T, c, n in dummies():
        T = T.copy(); T[:, :, 2] += S.get(n, 0); out.append((T, c, n))
    return out
def save(items, name, elev, azim, size=(9, 7), lim=None, title=None):
    fig = plt.figure(figsize=size); ax = fig.add_subplot(111, projection='3d'); draw(ax, items, elev, azim, lim)
    if title: ax.set_title(title, fontsize=10)
    fig.savefig(name, dpi=110, bbox_inches='tight'); plt.close(fig)
A = assembly()
save(A, 'assembly_view.png', 28, -55, title='ADCS-1 REV 2 assembled (flywheel mounted hub-down, nut pockets facing the platform)')
save(A, 'assembly_top.png', 90, -90, title='Top view')
save(A, 'assembly_side.png', 0, -90, title='Side view (looking along +y)')
ex = {'base': -30, 'spacer': -12, 'bearing': -18, 'platform': 0, 'motor_mount': 12, 'battery_retainer': 20, 'holder': 4, 'motor': 24, 'flywheel': 52, 'wheel_cover': 40}
save(assembly(ex), 'assembly_exploded.png', 22, -60, size=(9, 9), title='Exploded view')
fw = [(load_stl('stl/flywheel.stl'), COL['flywheel'], 'flywheel')]
save(fw, 'flywheel_closeup.png', 38, -60, size=(7, 6), title='Flywheel in PRINT orientation (pockets up, hub up). Mounted upside down.')
# sections ---------------------------------------------------------------
T = load_stl('stl/flywheel.stl')
def section(plane_val, axes):  # axes: which 2 coords form the picture plane; plane through the third = plane_val
    idx = {'x': 0, 'y': 1, 'z': 2}; a, b = axes; third = [k for k in 'xyz' if k not in axes][0]
    T2 = T[:, :, [idx[a], idx[b], idx[third]]]
    img = raster_fill(T2, plane_val + 1e-4, 0.05, ((-36, -1), (36, 15))); return img
fig, axs = plt.subplots(1, 2, figsize=(14, 4.6), gridspec_kw=dict(width_ratios=[2.3, 1]))
img = section(0.0, 'xz')
ax = axs[0]; ax.imshow(img, origin='lower', extent=(-36, 36, -1, 15), cmap='Blues', vmin=0, vmax=1.6, interpolation='nearest')
for sx in (-1, 1):   # two M8 nuts lie on the y=0 plane (pockets at 0 and 180 deg): flats radial, 13 AF, 6.5 thick, resting on the 1.2 mm floor
    ax.add_patch(plt.Rectangle((sx * 24.5 - 6.5, 1.2), 13, 6.5, fill=True, color='#555', alpha=.8))
ax.add_patch(plt.Rectangle((-1.5, 6.0), 3.0, 8.0, color='goldenrod', alpha=.9)); ax.text(0, 14.5, 'shaft (8 mm engaged)', ha='center', fontsize=8)
ax.set_title('Section y = 0 (print orientation): two M8 nuts (dark) in pockets, 1.2 mm floor, D bore; shaft enters from the hub end at the top', fontsize=9)
ax.text(-24.5, 9.0, 'M8 nut', ha='center', fontsize=8); ax.set_aspect('equal'); ax.set_xlabel('x mm'); ax.set_ylabel('z mm')
img = np.zeros(1)
T2 = T[:, :, [1, 2, 0]]; img = raster_fill(T2, 1e-4, 0.05, ((-12, -1), (12, 15)))
ax = axs[1]; ax.imshow(img, origin='lower', extent=(-12, 12, -1, 15), cmap='Blues', vmin=0, vmax=1.6, interpolation='nearest')
zs = P['WH_T'] + P['SCREW_ABOVE_DISC']
ax.add_patch(plt.Rectangle((-4.1, zs - 1.5), 4.1 - 0.9 + 0.2, 3.0, color='crimson', alpha=.85)); ax.text(-8.6, zs + 2.6, 'M3x5..8 grub\nscrew, open channel', fontsize=7)
ax.add_patch(plt.Rectangle((-1.0 + 0.0, 6.0), 1.0 + 1.5, 8.0, color='goldenrod', alpha=.5))
ax.set_title('Section x = 0 (y horizontal): open-top channel + nut slot', fontsize=9); ax.set_aspect('equal'); ax.set_xlabel('y mm')
plt.tight_layout(); fig.savefig('flywheel_section.png', dpi=120); plt.close(fig)
print('renders written')
