// platform.scad  DRAFT NOT MEASURED. Plate that bolts to the bearing top plate.
// Print: top face up, no supports, 0.2 mm layers, 3 walls, 20% infill.
PRINT = false;
include <params.scad>

module outline2d(){ rrect(PL_X, PL_Y, PL_R); }

module cavity2d(c, extra=0){
  translate([c[1], c[2]]) square([c[3]+2*(CL+extra), c[4]+2*(CL+extra)], center=true);
}
module open2d(c){
  s = c[7];
  if (s == "+y") translate([c[1], c[2]+c[4]/2+CL+RIM_W/2]) square([c[3]+2*CL, RIM_W+2], center=true);
  if (s == "-y") translate([c[1], c[2]-c[4]/2-CL-RIM_W/2]) square([c[3]+2*CL, RIM_W+2], center=true);
}
module rim2d(){
  difference(){
    union(){
      for (c = PCOMPS) cavity2d(c, RIM_W);
      // ballast bay walls
      translate([BAL_X, BAL_Y]) square([BAL_W+2*(CL+1.6), BAL_W+2*(CL+1.6)], center=true);
      // end stops for the battery holder
      for (s=[-1,1]) translate([s*(BAT_W/2+1.5+BAT_END_WALL/2), 0]) square([BAT_END_WALL, 34], center=true);
    }
    union(){
      for (c = PCOMPS) { cavity2d(c, 0); open2d(c); }
      translate([BAL_X, BAL_Y]) square([BAL_W+2*CL, BAL_W+2*CL], center=true);
      // keep rims off the arch feet
      for (s=[-1,1]) translate([0, s*FOOT_SCREW_Y]) square([LEG_X+1, FOOT_Y+1], center=true);
    }
  }
}

module platform(){
  difference(){
    union(){
      // plate
      translate([0,0,-PL_T]) linear_extrude(PL_T) outline2d();
      // module rims (tall ones)
      intersection(){
        linear_extrude(RIM_H) outline2d();
        linear_extrude(RIM_H) difference(){ rim2d(); translate([BAL_X,BAL_Y]) square(0.01); }
      }
      // ballast bay is taller
      translate([0,0,0]) linear_extrude(6) intersection(){
        outline2d();
        difference(){
          translate([BAL_X, BAL_Y]) square([BAL_W+2*(CL+1.6), BAL_W+2*(CL+1.6)], center=true);
          translate([BAL_X, BAL_Y]) square([BAL_W+2*CL, BAL_W+2*CL], center=true);
        }
      }
      // bearing corner bosses
      for (sx=[-1,1], sy=[-1,1]) translate([sx*B_HOLE_P, sy*B_HOLE_P, -PL_T]) translate([-BOSS_W/2,-BOSS_W/2,0]) cube([BOSS_W, BOSS_W, PL_T+BOSS_H]);
      // arch leg bosses
      for (s=[-1,1]) translate([-LEG_X/2, s*FOOT_SCREW_Y-FOOT_Y/2, -PL_T]) cube([LEG_X, FOOT_Y, PL_T+BOSS_H]);
    }
    // bearing screw holes + nut pockets from the top
    for (sx=[-1,1], sy=[-1,1]) translate([sx*B_HOLE_P, sy*B_HOLE_P, 0]) {
      translate([0,0,-PL_T-1]) cylinder(d=M3_CLR, h=PL_T+BOSS_H+2, $fn=24);
      translate([0,0,BOSS_H-NUT_POCKET]) hex_prism(M3_NUT_AF+NUT_SLACK, NUT_POCKET+1);
    }
    // arch screw holes + nut pockets from below
    for (s=[-1,1]) translate([0, s*FOOT_SCREW_Y, 0]) {
      translate([0,0,-PL_T-1]) cylinder(d=M3_CLR, h=PL_T+BOSS_H+2, $fn=24);
      translate([0,0,-PL_T-1]) hex_prism(M3_NUT_AF+NUT_SLACK, NUT_POCKET+1);
    }
    // cable tie slots for the hold-down bars
    for (sx=[-1,1], sy=[-1,1]) translate([sx*RB_X, sy*TIE_Y, -PL_T-1]) translate([-TIE_SLOT_X/2, -TIE_SLOT_Y/2, 0]) cube([TIE_SLOT_X, TIE_SLOT_Y, PL_T+RIM_H+4]);
    // trim pockets (stick washers or coins here with tape to balance)
    for (sx=[-1,1], sy=[-1,1]) translate([sx*TRIM_X, sy*TRIM_Y, -TRIM_DEPTH]) cylinder(d=TRIM_D, h=TRIM_DEPTH+1, $fn=40);
    // arrow marker for USB direction
  }
}
platform();
