"""CoM table and inertia estimate for the rotating assembly, from params.scad and the PLACED STLs (numpy only).
Printed-part masses are ESTIMATES (volume x PLA density x FILL). Weigh the real parts and edit params.scad."""
import math, numpy as np
from meshlib import load_stl, mass_props
from pyparams import load
P = load(); RHO = 1.24e-3
FILL = dict(platform=0.45, motor_mount=0.60, battery_retainer=1.0, spacer=1.0, flywheel=1.0, wheel_cover=1.0)   # DRAFT: weigh after printing
rows = []
def add(name, m, x, y, izz=0.0): rows.append((name, m, x, y, izz))
for label, n in (('platform (printed)', 'platform'), ('arch / motor mount (printed)', 'motor_mount'), ('hold-down bars x2 (printed)', 'battery_retainer'),
                 ('spacers x4 (printed)', 'spacer'), ('flywheel plastic (printed, 100% infill)', 'flywheel'), ('wheel cover (printed, 100%)', 'wheel_cover')):
    V, c, I = mass_props(load_stl(f'stl/placed/{n}.stl')); m = V * RHO * FILL[n]
    add(label, m, c[0], c[1], 0.0); rows[-1] = (label, m, c[0], c[1], I * RHO * FILL[n] - m * (c[0] ** 2 + c[1] ** 2))
for c in P['COMPS']: add(c['name'], c['m'], c['x'], c['y'], c['m'] * (c['w'] ** 2 + c['h'] ** 2) / 12)
add('battery holder + 2 cells', P['M_BATT'], 0, 0, P['M_BATT'] * (P['BAT_W'] ** 2 + P['BAT_D'] ** 2) / 12)
add('N20 motor', P['M_MOTOR'], 0, 0, 0)
cx = np.mean([c['x'] for c in P['COMPS']]); cy = np.mean([c['y'] for c in P['COMPS']])
add('wires (at electronics centroid)', P['M_WIRES'], cx, cy, 0)
add('ballast bay contents', P['BAL_G'], P['BAL_X'], P['BAL_Y'], 0)
add('8 steel M8 nuts', P['N_NUTS'] * P['NUT_M'], 0, 0, 0)
add('bearing top plate', P['B_TOP_M'], 0, 0, P['B_TOP_M'] * (2 * 96 ** 2) / 12 * 0.85)
add('4 screws + 4 nuts at (+-41,+-41)', 8.0, 0, 0, 0)
add('M3 screws/nuts, grub screw, cable ties', 6.0, 0, 0, 0)
tot = sum(r[1] for r in rows)
X = sum(r[1] * r[2] for r in rows) / tot; Y = sum(r[1] * r[3] for r in rows) / tot
print(f"{'item':42s} {'m g':>7s} {'x':>7s} {'y':>7s} {'m*x':>9s} {'m*y':>9s}")
for n, m, x, y, _ in rows: print(f"{n:42s} {m:7.1f} {x:7.1f} {y:7.1f} {m * x:9.0f} {m * y:9.0f}")
print(f"{'TOTAL rotating (without wheel plastic spin)':42s} {tot:7.1f}")
print(f"CoM offset from the bearing axis (MODEL RESULT, not a physical measurement): x = {X:+.2f} mm, y = {Y:+.2f} mm, |r| = {math.hypot(X, Y):.2f} mm  (target < 1 mm, limit 2 mm)")
Jb = 0.0
for n, m, x, y, I in rows:
    if n.startswith('flywheel') or n.startswith('8 steel') or n.startswith('wheel cover'): continue
    Jb += m * (x * x + y * y) + I
Jb += 8.0 * 58 ** 2; Jb *= 1e-9
pl = [r for r in rows if r[0].startswith('flywheel') or r[0].startswith('wheel cover')]
Jw_pl = sum(r[4] + r[1] * (r[2] ** 2 + r[3] ** 2) for r in pl)
Jw = (P['N_NUTS'] * (P['NUT_M'] * P['WH_RING_R'] ** 2 + P['NUT_M'] * (6.5 ** 2 + 4 ** 2) / 2) + Jw_pl) * 1e-9
mw = sum(r[1] for r in pl) + P['N_NUTS'] * P['NUT_M']
print(f"\nJ_b (body, excluding wheel spin) = {Jb:.2e} kg m2   [model]")
print(f"J_w (8 nuts + printed disc/hub/cover) = {Jw:.2e} kg m2   wheel mass {mw:.1f} g  [model; nuts at 5.5 g assumed, weigh them]")
rate = 0.69   # rad/s peak body rate for a 30 deg prefiltered step (from the earlier control design, NOT re-derived here)
print("\nWheel speed scenarios. rpm = 60*fps/28 frames-per-turn. 'usable' = 65% of no-load (load + battery sag), a judgement, not a measurement.")
print(f"{'video fps':>9s} {'no-load rpm':>11s} {'no-load rad/s':>13s} {'usable rad/s':>12s} {'min J_w':>9s} {'margin':>7s}")
for fps in (120, 240, 480):
    w0 = 2 * math.pi * (60 * fps / 28) / 60; w = 0.65 * w0; need = Jb * rate / (w - rate)
    print(f"{fps:9d} {60 * fps / 28:11.0f} {w0:13.1f} {w:12.1f} {need:9.2e} {Jw / need:6.1f}x")
for w in (21.6, 35.0):
    need = Jb * rate / (w - rate); print(f"  earlier assumption {w:4.1f} rad/s usable: min J_w = {need:.2e}, margin = {Jw / need:.1f}x")
print(f"  peak body torque for the 30 deg step ~ J_b*wn^2*step = {Jb * 2.86 ** 2 * math.radians(30) * 1e3:.2f} mN m   (motor torque still UNMEASURED)")
print("  nut centrifugal load at the no-load speeds: F = m w^2 r = " + ", ".join(f"{5.5e-3 * (2 * math.pi * (60 * f / 28) / 60) ** 2 * 0.0245:.2f} N @ {f} fps" for f in (120, 240, 480)))
