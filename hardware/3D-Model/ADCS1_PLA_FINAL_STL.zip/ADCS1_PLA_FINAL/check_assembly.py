"""Assembly collision + clearance check on the PLACED STLs plus dummy bodies. numpy/scipy only (no trimesh).
Voxel size 0.25 mm: distances are good to about +-0.25 mm. Run:  python3 check_assembly.py"""
import sys, math, itertools, numpy as np
from scipy import ndimage as ndi
from meshlib import load_stl, raster_fill
from pyparams import load
P = load(); RES = 0.25
FY = P['LEG_IN'] + P['LEG_Y'] + P['FOOT_Y'] / 2
D = sys.argv[1] if len(sys.argv) > 1 else 'stl/placed'

class Mesh:
    def __init__(s, name, f):
        s.name = name; s.tri = load_stl(f); q = s.tri.reshape(-1, 3); s.lo = q.min(0); s.hi = q.max(0)
    def vox(s, lo, hi):
        nx = int(round((hi[0] - lo[0]) / RES)); ny = int(round((hi[1] - lo[1]) / RES)); nz = int(round((hi[2] - lo[2]) / RES))
        m = np.zeros((nx, ny, nz), bool)
        zc = lo[2] + (np.arange(nz) + 0.5) * RES
        sel = s.tri[(s.tri[:, :, 2].max(1) >= lo[2]) & (s.tri[:, :, 2].min(1) <= hi[2])]
        for k, z in enumerate(zc):
            if z < s.lo[2] or z > s.hi[2]: continue
            img = raster_fill(sel, z, RES, ((lo[0], lo[1]), (hi[0], hi[1])))
            m[:, :, k] = img.T[:nx, :ny] if img.shape == (ny, nx) else False
        return m
class Dummy:
    def __init__(s, name, lo, hi, fn): s.name = name; s.lo = np.array(lo, float); s.hi = np.array(hi, float); s.fn = fn
    def vox(s, lo, hi):
        nx = int(round((hi[0] - lo[0]) / RES)); ny = int(round((hi[1] - lo[1]) / RES)); nz = int(round((hi[2] - lo[2]) / RES))
        x = lo[0] + (np.arange(nx) + .5) * RES; y = lo[1] + (np.arange(ny) + .5) * RES; z = lo[2] + (np.arange(nz) + .5) * RES
        X, Y, Z = np.meshgrid(x, y, z, indexing='ij'); return s.fn(X, Y, Z)
def boxd(name, x0, x1, y0, y1, z0, z1):
    return Dummy(name, (x0, y0, z0), (x1, y1, z1), lambda X, Y, Z: (X >= x0) & (X <= x1) & (Y >= y0) & (Y <= y1) & (Z >= z0) & (Z <= z1))
bodies = [Mesh(n, f'{D}/{n}.stl') for n in ('platform', 'spacer', 'base', 'battery_retainer', 'flywheel', 'wheel_cover', 'motor_mount')]
zt = -P['PL_T'] - P['SP_H']; r0 = P['B_OPEN_D'] / 2
bodies.append(Dummy('bearing', (-48, -48, zt - P['B_T']), (48, 48, zt), lambda X, Y, Z: (np.abs(X) <= 48) & (np.abs(Y) <= 48) & (Z >= zt - P['B_T']) & (Z <= zt) & (X * X + Y * Y >= r0 * r0)))
for c in P['COMPS']: bodies.append(boxd(c['name'], c['x'] - c['w'] / 2, c['x'] + c['w'] / 2, c['y'] - c['h'] / 2, c['y'] + c['h'] / 2, 0, c['ht']))
bodies.append(boxd('holder', -P['BAT_W'] / 2, P['BAT_W'] / 2, -P['BAT_D'] / 2, P['BAT_D'] / 2, 0, P['BAT_H']))
bodies.append(boxd('motor', -P['MOT_W'] / 2, P['MOT_W'] / 2, -P['MOT_D'] / 2, P['MOT_D'] / 2, P['MOT_Z0'], P['MOT_TOP']))
zs0 = P['MOT_TOP']; fl = P['MOT_SHAFT_D'] / 2 - P['MOT_FLAT']
bodies.append(Dummy('shaft', (-1.6, -1.6, zs0), (1.6, 1.6, zs0 + P['MOT_SHAFT']), lambda X, Y, Z: (X * X + Y * Y <= 2.25) & (Y >= fl) & (Z >= zs0) & (Z <= zs0 + P['MOT_SHAFT'])))
hz = P['BOSS_H'] + P['FOOT_T'] - P['HEAD_REC'] + 0.4   # screw head seat (head sits 0.4 above recess floor? recess floor + 0)
hz = P['BOSS_H'] + P['FOOT_T'] - P['HEAD_REC']
for s in (1, -1):   # M3x8 arch screws: head 2.6 on the recess floor, shank 8 long
    bodies.append(Dummy(f'archscrew{s:+d}', (-3, s * FY - 3, hz - 8), (3, s * FY + 3, hz + 2.6),
        lambda X, Y, Z, s=s: ((X ** 2 + (Y - s * FY) ** 2 <= 2.25) & (Z >= hz - 8) & (Z <= hz)) | ((X ** 2 + (Y - s * FY) ** 2 <= 2.9 ** 2) & (Z >= hz) & (Z <= hz + 2.6))))
zc = P['MOT_Z0'] + P['SOCK_H'] / 2; yc = P['CLAMP_Y']; xf = -P['SOCK_X'] / 2 + P['HEAD_REC']
bodies.append(Dummy('clampscrew', (xf - 2.6, yc - 3, zc - 3), (xf + 16, yc + 3, zc + 3),
    lambda X, Y, Z: (((Y - yc) ** 2 + (Z - zc) ** 2 <= 2.25) & (X >= xf) & (X <= xf + 16)) | (((Y - yc) ** 2 + (Z - zc) ** 2 <= 2.9 ** 2) & (X >= xf - 2.6) & (X <= xf))))
EXPECT_CONTACT = {frozenset(p) for p in [('platform', 'spacer'), ('spacer', 'bearing'), ('bearing', 'base'), ('platform', 'motor_mount'), ('platform', 'holder'),
    ('motor_mount', 'motor'), ('battery_retainer', 'holder'), ('motor', 'shaft'), ('motor_mount', 'archscrew+1'), ('motor_mount', 'archscrew-1'),
    ('platform', 'archscrew+1'), ('platform', 'archscrew-1'), ('motor_mount', 'clampscrew'), ('flywheel', 'shaft'), ('flywheel', 'wheel_cover')]}
def check_pair(a, b, margin=3.0):
    lo = np.maximum(a.lo, b.lo) - margin; hi = np.minimum(a.hi, b.hi) + margin
    if np.any(hi <= lo): return None
    lo = np.floor(lo / RES) * RES; hi = np.ceil(hi / RES) * RES
    A = a.vox(lo, hi); B = b.vox(lo, hi)
    if not A.any() or not B.any(): return None
    ov = (A & B).sum() * RES ** 3
    if ov > 0: return ov, 0.0
    dt = ndi.distance_transform_edt(~A, sampling=RES); return 0.0, float(dt[B].min())
print(f"{'pair':36s} {'overlap mm3':>11s} {'min gap mm':>10s}  note")
bad = 0; rows = []
for a, b in itertools.combinations(bodies, 2):
    # quick reject on bounding boxes (gap > 3 mm)
    if np.any(a.lo - b.hi > 3) or np.any(b.lo - a.hi > 3): continue
    r = check_pair(a, b)
    if r is None: continue
    ov, gap = r; exp = frozenset((a.name, b.name)) in EXPECT_CONTACT
    # comp-on-platform pads are designed to sit on the platform plate
    on_plate = 'platform' in (a.name, b.name) and gap <= 0.3 and ov == 0
    note = 'designed contact' if (exp or on_plate) else ''
    if ov > 1.0 and not exp: note = 'COLLISION'; bad += 1
    if (ov > 1.0 and not exp) or (gap < 1.5 and not note):
        print(f"{a.name + ' / ' + b.name:36s} {ov:11.1f} {gap:10.2f}  {note}")
    if ov > 1.0 and exp: print(f"{a.name + ' / ' + b.name:36s} {ov:11.1f} {gap:10.2f}  overlap on a designed-contact pair (threads/fit, inspect)")
# wheel swept envelope (axisymmetric) against everything that does not spin with it
wh = [b for b in bodies if b.name in ('flywheel', 'wheel_cover')]
lo = np.array([-40, -40, 40.0]); hi = np.array([40, 40, 80.0])
NXY = int(80 / RES); NZ = int(40 / RES)
env = np.zeros((NZ, int(40 / RES)), bool)   # [z, r]
for w in wh:
    W = w.vox(lo, hi); X, Y, Z = np.meshgrid(np.arange(NXY) * RES - 40 + RES / 2, np.arange(NXY) * RES - 40 + RES / 2, np.arange(NZ), indexing='ij')
    ri = (np.hypot(X, Y) / RES).astype(int); zi = Z.astype(int)
    m = W & (ri < env.shape[1]); env[zi[m], ri[m]] = True
dt = ndi.distance_transform_edt(~env, sampling=RES)
worst = 1e9
for b in bodies:
    if b.name in ('flywheel', 'wheel_cover', 'shaft', 'bearing', 'base', 'spacer'): continue
    if b.hi[2] < 40 or b.lo[2] > 80: continue
    B = b.vox(lo, hi)
    if not B.any(): continue
    X, Y, Z = np.meshgrid(np.arange(NXY) * RES - 40 + RES / 2, np.arange(NXY) * RES - 40 + RES / 2, np.arange(NZ), indexing='ij')
    ri = np.minimum((np.hypot(X, Y) / RES).astype(int), env.shape[1] - 1); zi = Z.astype(int)
    d = dt[zi[B], ri[B]]; g = float(d.min()); worst = min(worst, g)
    print(f"swept wheel envelope vs {b.name:18s}: min clearance {g:5.2f} mm" + ("   <-- COLLISION" if g < 0.25 else ""))
    if g < 0.25: bad += 1
print("min swept-wheel clearance to non-spinning parts:", round(worst, 2), "mm (2.0 required by the brief; 1.5 to platform components)")
print("RESULT:", "COLLISIONS FOUND" if bad else "no collisions among modelled bodies")
sys.exit(1 if bad else 0)
