"""Mesh checks on every print STL: watertight, orientation consistency, bodies, degenerate faces, bbox, build volume, mass estimate. numpy only."""
import sys, os, glob
from meshlib import load_stl, integrity
FILL = dict(platform=0.45, base=0.45, motor_mount=0.60, flywheel=1.0, wheel_cover=1.0, spacer=1.0, battery_retainer=1.0)  # DRAFT: weigh after printing
RHO = 1.24e-3; BED = (220, 220, 250); MARGIN = 5.0
expected_bodies = dict(battery_retainer=2)
ok = True
print(f"{'part':18s} {'closed':>6s} {'wind':>4s} {'bodies':>6s} {'zero-area':>9s} {'size mm':>22s} {'vol cm3':>8s} {'mass g':>7s}  bed(220x220x250, 5 mm margin)")
for f in sorted(glob.glob('stl/*.stl')):
    n = os.path.basename(f)[:-4]; r = integrity(load_stl(f)); sz = r['bbox_max'] - r['bbox_min']
    fits = sz[0] <= BED[0] - 2 * MARGIN and sz[1] <= BED[1] - 2 * MARGIN and sz[2] <= BED[2]
    good = r['watertight'] and r['components'] == expected_bodies.get(n, 1) and fits
    ok &= bool(good)
    print(f"{n:18s} {str(r['watertight']):>6s} {r['inconsistent_winding_edges']:4d} {r['components']:6d} {r['degenerate']:9d} {sz[0]:7.1f}x{sz[1]:5.1f}x{sz[2]:5.1f} {r['volume'] / 1000:8.2f} {r['volume'] * RHO * FILL[n]:7.1f}  {'fits' if fits else 'TOO BIG'}")
print("ALL CLOSED, CORRECT BODY COUNT, WITHIN THE BED:", ok)
sys.exit(0 if ok else 1)
