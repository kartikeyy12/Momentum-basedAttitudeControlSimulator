// assembly.scad  debug view. Open in OpenSCAD. Parts are placed as installed, dummies are grey/blue.
include <params.scad>
use <platform.scad>
use <spacer.scad>
use <base.scad>
use <battery_retainer.scad>
use <flywheel.scad>
use <wheel_cover.scad>
use <motor_mount.scad>
SECTION = false;     // true cuts the model at y=0 to see the stack up
module dummy_bearing(){
  color("silver") translate([0,0,-PL_T-SP_H-B_T]) difference(){
    translate([-B_W/2,-B_W/2,0]) cube([B_W,B_W,B_T]);
    translate([0,0,-1]) cylinder(d=B_OPEN_D,h=B_T+2,$fn=60);
  }
}
module dummy_comps(){
  for (c=PCOMPS) color("seagreen") translate([c[1]-c[3]/2, c[2]-c[4]/2, 0]) cube([c[3],c[4],c[5]]);
  color("gold") translate([-BAT_W/2,-BAT_D/2,0]) cube([BAT_W,BAT_D,BAT_H]);
  color("dimgray") translate([-MOT_W/2,-MOT_D/2,MOT_Z0]) cube([MOT_W,MOT_D,MOT_L]);
  color("dimgray") translate([0,0,MOT_TOP]) cylinder(d=MOT_SHAFT_D,h=MOT_SHAFT,$fn=20);
}
module all(){
  platform(); spacer_placed(); base_placed(); retainer_placed(); flywheel_placed(); wheel_cover_placed(); motor_mount();
  dummy_bearing(); dummy_comps();
}
if (SECTION) intersection(){ all(); translate([-200,0,-200]) cube([400,200,400]); } else all();
