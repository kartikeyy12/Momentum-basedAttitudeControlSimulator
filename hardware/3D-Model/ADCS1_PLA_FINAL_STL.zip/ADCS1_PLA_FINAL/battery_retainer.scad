// battery_retainer.scad  print 2. Bar over each end of the holder, held by a cable tie loop
// that goes through the platform slots. DRAFT NOT MEASURED.
PRINT = false;
include <params.scad>
module retainer(){
  difference(){
    translate([-RB_W/2, -RB_L/2, 0]) cube([RB_W, RB_L, RB_T]);
    // groove along the length for the tie
    translate([-TIE_GROOVE/2, -RB_L/2-1, RB_T-1.2]) cube([TIE_GROOVE, RB_L+2, 2]);
  }
}
module retainer_placed(){ for (s=[-1,1]) translate([s*RB_X, 0, BAT_H]) retainer(); }
if (PRINT) { retainer(); translate([RB_W+6,0,0]) retainer(); }
else retainer_placed();
