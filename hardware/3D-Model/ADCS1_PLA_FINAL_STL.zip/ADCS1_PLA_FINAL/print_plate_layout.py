"""Arrange the print STLs on 220x220 mm plates, verify margins/overlaps, draw print_plate_layout.png."""
import itertools, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle
from meshlib import load_stl
def bb(n):
    t = load_stl(f'stl/{n}.stl').reshape(-1, 3); return t.max(0)[:2] - t.min(0)[:2]
S = {n: bb(n) for n in ('platform', 'base', 'motor_mount', 'flywheel', 'wheel_cover', 'spacer', 'battery_retainer')}
plates = {
 'Plate 1': [('platform', 5, 5), ('motor_mount', 172, 5), ('battery_retainer', 172, 82)] + [('spacer', 5 + 16 * i, 146) for i in range(4)],
 'Plate 2': [('base', 5, 5), ('flywheel', 135, 5), ('wheel_cover', 135, 83)]}
GAP = 5.0; ok = True
fig, axs = plt.subplots(1, 2, figsize=(13, 6.6))
for ax, (pn, items) in zip(axs, plates.items()):
    ax.add_patch(Rectangle((0, 0), 220, 220, fill=False, lw=2)); ax.add_patch(Rectangle((5, 5), 210, 210, fill=False, ls='--', color='grey'))
    rects = []
    for n, x, y in items:
        w, h = S[n]; rects.append((n, x, y, w, h))
        if n in ('flywheel', 'wheel_cover'): ax.add_patch(Circle((x + w / 2, y + h / 2), w / 2, alpha=.5, color='tab:orange'))
        else: ax.add_patch(Rectangle((x, y), w, h, alpha=.5, color='tab:blue'))
        ax.text(x + w / 2, y + h / 2, n if n != 'spacer' else 'sp', ha='center', va='center', fontsize=7)
        if x < 5 - 1e-9 or y < 5 - 1e-9 or x + w > 215 + 1e-9 or y + h > 215 + 1e-9: ok = False; print('EDGE MARGIN VIOLATION', n)
    for a, b in itertools.combinations(rects, 2):
        gx = max(a[1] - (b[1] + b[3]), b[1] - (a[1] + a[3])); gy = max(a[2] - (b[2] + b[4]), b[2] - (a[2] + a[4]))
        if max(gx, gy) < GAP - 1e-9: ok = False; print('GAP VIOLATION', a[0], b[0], round(max(gx, gy), 1))
    ax.set_xlim(-3, 223); ax.set_ylim(-3, 223); ax.set_aspect('equal'); ax.set_title(f'{pn}  (bed 220x220, dashed = 5 mm margin)')
plt.tight_layout(); plt.savefig('print_plate_layout.png', dpi=110)
print('Plates needed: 2. All parts >= 5 mm from the bed edge and >= 5 mm apart:', ok)
for pn, items in plates.items(): print(pn, [n for n, _, _ in items])
