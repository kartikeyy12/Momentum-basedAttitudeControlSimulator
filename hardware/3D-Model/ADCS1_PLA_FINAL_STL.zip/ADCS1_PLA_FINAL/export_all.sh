#!/bin/bash
# Regenerates every STL from the .scad sources with OpenSCAD, then runs the checks. Run in WSL / Linux: bash export_all.sh
set -e
command -v openscad >/dev/null || { echo "openscad not found (sudo apt install openscad)"; exit 1; }
mkdir -p stl stl/placed
for p in platform base motor_mount flywheel wheel_cover spacer battery_retainer; do
  echo "== $p"
  openscad -o stl/$p.stl        -D PRINT=true  $p.scad 2>&1 | grep -i -E "warning|error|Simple:" || true
  openscad -o stl/placed/$p.stl -D PRINT=false $p.scad 2>&1 | grep -i -E "warning|error" || true
done
python3 check_parts.py
python3 check_assembly.py
python3 com_table.py
echo "Compare the volumes printed by check_parts.py with the table in README.md section 3 (expected within 0.5 %)."
