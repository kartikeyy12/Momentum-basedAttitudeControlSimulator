// spacer.scad  print 4. DRAFT NOT MEASURED: SP_H must match the bearing ring and screw heads.
PRINT = false;
include <params.scad>
module spacer(){
  difference(){
    translate([-SP_W/2,-SP_W/2,0]) cube([SP_W,SP_W,SP_H]);
    translate([0,0,-1]) cylinder(d=M3_CLR, h=SP_H+2, $fn=24);
  }
}
module spacer_placed(){ for (sx=[-1,1], sy=[-1,1]) translate([sx*B_HOLE_P, sy*B_HOLE_P, -PL_T-SP_H]) spacer(); }
if (PRINT) spacer(); else spacer_placed();
