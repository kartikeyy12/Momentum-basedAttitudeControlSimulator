// wheel_cover.scad  REV 2 (new, recommended). Flat disc glued over the pocket face of the flywheel after the nuts are glued in.
// Print flat, 100% infill. It stops the nuts falling out axially because the pockets face down when the wheel is mounted.
PRINT = false;
include <params.scad>
module wheel_cover(){
  difference(){
    cylinder(d=COVER_D, h=COVER_T, $fn=120);
    translate([0,0,-1]) cylinder(d=COVER_HOLE, h=COVER_T+2, $fn=60);
  }
}
module wheel_cover_placed(){ translate([0,0,WH_Z0+WH_HUB_H-WH_T-COVER_T]) wheel_cover(); }
if (PRINT) wheel_cover(); else wheel_cover_placed();
