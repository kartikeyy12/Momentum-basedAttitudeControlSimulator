"""Minimal numpy-only mesh toolkit (no trimesh / OpenSCAD available in this sandbox).
load_stl, integrity report, plane slicing to loops, even-odd rasterisation of a slice.
"""
import struct, re
import numpy as np
from collections import defaultdict


def load_stl(path):
    data = open(path, 'rb').read()
    if data[:5] == b'solid' and b'facet' in data[:400]:
        txt = data.decode('latin1')
        v = np.array(re.findall(r'vertex\s+(\S+)\s+(\S+)\s+(\S+)', txt), dtype=float)
        tri = v.reshape(-1, 3, 3)
    else:
        n = struct.unpack('<I', data[80:84])[0]
        arr = np.frombuffer(data, dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]),
                            count=n, offset=84)
        tri = arr['v'].astype(float)
    return tri  # (N,3,3)


def weld(tri, tol=1e-4):
    """Return (verts, faces) with vertices merged on a tol grid."""
    flat = tri.reshape(-1, 3)
    key = np.round(flat / tol).astype(np.int64)
    uniq, inv = np.unique(key, axis=0, return_inverse=True)
    verts = np.zeros((len(uniq), 3))
    verts[inv.ravel()] = flat
    faces = inv.reshape(-1, 3)
    return verts, faces


def volume(tri):
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    return float(np.einsum('ij,ij->i', a, np.cross(b, c)).sum() / 6.0)


def area(tri):
    return float(0.5 * np.linalg.norm(np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0]), axis=1).sum())


def integrity(tri):
    verts, faces = weld(tri)
    nondeg = np.array([len({*f}) == 3 for f in faces])
    # degenerate by area
    ar = 0.5 * np.linalg.norm(np.cross(verts[faces[:, 1]] - verts[faces[:, 0]],
                                       verts[faces[:, 2]] - verts[faces[:, 0]]), axis=1)
    degenerate = int((ar < 1e-9).sum() + (~nondeg).sum())
    f = faces[nondeg]
    # directed edge counting: closed + consistently oriented <=> every directed edge appears once and its reverse once
    e = np.concatenate([f[:, [0, 1]], f[:, [1, 2]], f[:, [2, 0]]])
    und = np.sort(e, axis=1)
    key_u = und[:, 0].astype(np.int64) * len(verts) + und[:, 1]
    _, counts = np.unique(key_u, return_counts=True)
    open_edges = int((counts == 1).sum())
    nonmanifold = int((counts > 2).sum())
    dkey = e[:, 0].astype(np.int64) * len(verts) + e[:, 1]
    du, dc = np.unique(dkey, return_counts=True)
    dup_directed = int((dc > 1).sum())  # same directed edge used twice => inconsistent winding/dup
    # connected components (face adjacency through shared vertices)
    parent = list(range(len(verts)))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for a, b, c in f:
        ra, rb, rc = find(a), find(b), find(c)
        parent[rb] = ra
        parent[find(rc)] = find(ra)
    comps = len({find(i) for i in np.unique(f)})
    # duplicate faces
    sf = np.sort(f, axis=1)
    kf = sf[:, 0].astype(np.int64) * len(verts) ** 2 + sf[:, 1].astype(np.int64) * len(verts) + sf[:, 2]
    dupf = int(len(kf) - len(np.unique(kf)))
    return dict(tris=len(tri), verts=len(verts), open_edges=open_edges, nonmanifold_edges=nonmanifold,
                inconsistent_winding_edges=dup_directed, degenerate=degenerate, components=comps,
                duplicate_faces=dupf, watertight=(open_edges == 0 and nonmanifold == 0 and dup_directed == 0),
                volume=volume(tri), area=area(tri),
                bbox_min=tri.reshape(-1, 3).min(0), bbox_max=tri.reshape(-1, 3).max(0))


def slice_z(tri, z):
    """Return list of closed polylines (Nx2) where plane z cuts the mesh (z nudged off vertices)."""
    t = tri
    zz = t[:, :, 2]
    segs = []
    below = zz < z
    n_below = below.sum(1)
    idx = np.where((n_below == 1) | (n_below == 2))[0]
    for i in idx:
        p = t[i]
        b = below[i]
        pts = []
        for a, c in ((0, 1), (1, 2), (2, 0)):
            if b[a] != b[c]:
                s = (z - p[a, 2]) / (p[c, 2] - p[a, 2])
                pts.append(p[a, :2] + s * (p[c, :2] - p[a, :2]))
        if len(pts) == 2:
            segs.append((tuple(np.round(pts[0], 5)), tuple(np.round(pts[1], 5))))
    return segs


def segs_to_loops(segs):
    adj = defaultdict(list)
    for a, b in segs:
        adj[a].append(b)
        adj[b].append(a)
    used = set()
    loops = []
    for a, b in segs:
        k = (a, b) if a < b else (b, a)
        if k in used:
            continue
        loop = [a]
        cur, prev = b, a
        used.add(k)
        while cur != a:
            loop.append(cur)
            nxts = [n for n in adj[cur] if ((cur, n) if cur < n else (n, cur)) not in used]
            if not nxts:
                break
            nx = nxts[0]
            used.add((cur, nx) if cur < nx else (nx, cur))
            prev, cur = cur, nx
        loops.append(np.array(loop))
    return loops


def raster_slice(tri, z, res=0.1, bounds=None):
    """Even-odd raster of the cross-section at height z. Returns (bool image [y,x], x0, y0, res)."""
    from matplotlib.path import Path
    loops = segs_to_loops(slice_z(tri, z))
    if bounds is None:
        mn = tri.reshape(-1, 3).min(0)[:2] - 1
        mx = tri.reshape(-1, 3).max(0)[:2] + 1
    else:
        mn, mx = np.array(bounds[0]), np.array(bounds[1])
    nx = int(np.ceil((mx[0] - mn[0]) / res)); ny = int(np.ceil((mx[1] - mn[1]) / res))
    xs = mn[0] + (np.arange(nx) + 0.5) * res
    ys = mn[1] + (np.arange(ny) + 0.5) * res
    X, Y = np.meshgrid(xs, ys)
    pts = np.column_stack([X.ravel(), Y.ravel()])
    img = np.zeros(len(pts), bool)
    for lp in loops:
        if len(lp) < 3:
            continue
        img ^= Path(lp).contains_points(pts)
    return img.reshape(ny, nx), mn[0], mn[1], res


def ray_hits(tri, origin, axis):
    """Intersections of an axis-aligned ray (full line) with mesh. axis in 'x','y','z'. Returns sorted coordinates along axis."""
    ax = 'xyz'.index(axis)
    o = [i for i in range(3) if i != ax]
    p = np.array([origin[o[0]], origin[o[1]]])
    a = tri[:, :, o[0]]; b = tri[:, :, o[1]]
    # barycentric in 2D projection
    x0, y0 = a[:, 0], b[:, 0]
    x1, y1 = a[:, 1], b[:, 1]
    x2, y2 = a[:, 2], b[:, 2]
    det = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
    ok = np.abs(det) > 1e-12
    px, py = p
    l0 = np.where(ok, ((y1 - y2) * (px - x2) + (x2 - x1) * (py - y2)) / np.where(ok, det, 1), -1)
    l1 = np.where(ok, ((y2 - y0) * (px - x2) + (x0 - x2) * (py - y2)) / np.where(ok, det, 1), -1)
    l2 = 1 - l0 - l1
    eps = 1e-9
    hit = ok & (l0 >= -eps) & (l1 >= -eps) & (l2 >= -eps)
    c = tri[:, :, ax]
    vals = l0[hit] * c[hit, 0] + l1[hit] * c[hit, 1] + l2[hit] * c[hit, 2]
    vals = np.sort(vals)
    # merge duplicates from shared edges
    out = []
    for v in vals:
        if not out or abs(v - out[-1]) > 1e-6:
            out.append(v)
    return out


def solid_intervals(tri, origin, axis):
    h = ray_hits(tri, origin, axis)
    if len(h) % 2:
        return h, None
    return h, [(h[i], h[i + 1]) for i in range(0, len(h), 2)]


def slice_segments(tri, z):
    """Vectorised plane section -> array of segments (M,2,2). Triangles are classified with z-eps tie-break (vertex on plane counts as above)."""
    zz = tri[:, :, 2]
    above = zz >= z
    na = above.sum(1)
    sel = (na == 1) | (na == 2)
    T = tri[sel]; A = above[sel]
    segs = []
    # for each triangle find the two edges that cross
    for (i, j) in ((0, 1), (1, 2), (2, 0)):
        pass
    P = T
    pts = np.full((len(T), 2, 2), np.nan)
    cnt = np.zeros(len(T), int)
    for (i, j) in ((0, 1), (1, 2), (2, 0)):
        cross = A[:, i] != A[:, j]
        s = (z - P[:, i, 2]) / np.where(cross, P[:, j, 2] - P[:, i, 2], 1)
        q = P[:, i, :2] + s[:, None] * (P[:, j, :2] - P[:, i, :2])
        for k in range(len(T)):
            pass
        idx = np.where(cross)[0]
        pts[idx, cnt[idx]] = q[idx]
        cnt[idx] += 1
    return pts


def raster_fill(tri, z, res, bounds):
    """Robust even-odd scanline fill of the section at z. Returns bool image [ny,nx]."""
    (xmin, ymin), (xmax, ymax) = bounds
    nx = int(np.ceil((xmax - xmin) / res)); ny = int(np.ceil((ymax - ymin) / res))
    segs = slice_segments(tri, z)
    img = np.zeros((ny, nx), bool)
    if len(segs) == 0:
        return img
    p = segs[:, 0]; q = segs[:, 1]
    y0 = np.minimum(p[:, 1], q[:, 1]); y1 = np.maximum(p[:, 1], q[:, 1])
    r0 = np.ceil((y0 - ymin) / res - 0.5).astype(int)   # first row whose centre >= y0
    r1 = np.ceil((y1 - ymin) / res - 0.5).astype(int)   # first row whose centre >= y1 (excluded)
    rows = []; xs = []
    for k in range(len(segs)):
        if r1[k] <= r0[k]:
            continue
        rr = np.arange(max(r0[k], 0), min(r1[k], ny))
        if len(rr) == 0:
            continue
        yc = ymin + (rr + 0.5) * res
        t = (yc - p[k, 1]) / (q[k, 1] - p[k, 1])
        rows.append(rr); xs.append(p[k, 0] + t * (q[k, 0] - p[k, 0]))
    if not rows:
        return img
    rows = np.concatenate(rows); xs = np.concatenate(xs)
    o = np.lexsort((xs, rows)); rows = rows[o]; xs = xs[o]
    # pair up crossings per row
    start = 0
    uniq, first, counts = np.unique(rows, return_index=True, return_counts=True)
    for r, f, c in zip(uniq, first, counts):
        xr = xs[f:f + c]
        for a in range(0, c - 1, 2):
            c0 = int(np.ceil((xr[a] - xmin) / res - 0.5)); c1 = int(np.ceil((xr[a + 1] - xmin) / res - 0.5))
            img[r, max(c0, 0):max(min(c1, nx), 0)] = True
    return img


def mass_props(tri):
    """volume, centroid, and integral of (x^2+y^2) dV about the z axis through the origin (exact for a polyhedron)."""
    a, b, c = tri[:, 0], tri[:, 1], tri[:, 2]
    v = np.einsum('ij,ij->i', a, np.cross(b, c)) / 6.0
    V = v.sum()
    cen = ((a + b + c) / 4.0 * v[:, None]).sum(0) / V
    def second(ax):
        p = [a[:, ax], b[:, ax], c[:, ax]]
        s = p[0] ** 2 + p[1] ** 2 + p[2] ** 2 + p[0] * p[1] + p[0] * p[2] + p[1] * p[2]
        return (v / 10.0 * s * 6 / 6).sum() * 1.0
    # tetra (0,a,b,c): int x^2 = 6V_t/60 * (sum xi^2 + sum_{i<j} xi xj)  with V_t = v
    Ixx = (v * (1 / 10.0) * (lambda p: p[0] ** 2 + p[1] ** 2 + p[2] ** 2 + p[0] * p[1] + p[0] * p[2] + p[1] * p[2])([a[:, 0], b[:, 0], c[:, 0]])).sum()
    Iyy = (v * (1 / 10.0) * (lambda p: p[0] ** 2 + p[1] ** 2 + p[2] ** 2 + p[0] * p[1] + p[0] * p[2] + p[1] * p[2])([a[:, 1], b[:, 1], c[:, 1]])).sum()
    return float(V), cen, float(Ixx + Iyy)
