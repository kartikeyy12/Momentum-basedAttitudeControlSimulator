// base.scad  DRAFT NOT MEASURED. Bolts to the bearing bottom plate, nuts sit in pockets on the underside.
// Print: flat, no supports. Screws M3x8 from above through the bottom plate.
PRINT = false;
include <params.scad>
module base(){
  difference(){
    linear_extrude(BASE_T) rrect(BASE_X, BASE_Y, BASE_R);
    // bearing locating recess
    translate([0,0,BASE_T-BASE_RECESS_D]) translate([-BASE_RECESS/2,-BASE_RECESS/2,0]) cube([BASE_RECESS,BASE_RECESS,BASE_RECESS_D+1]);
    for (sx=[-1,1], sy=[-1,1]) translate([sx*B_HOLE_P, sy*B_HOLE_P, 0]) {
      translate([0,0,-1]) cylinder(d=M3_CLR, h=BASE_T+2, $fn=24);
      translate([0,0,-1]) hex_prism(M3_NUT_AF+NUT_SLACK, NUT_POCKET+1);
    }
    // feet recesses for self adhesive rubber feet
    for (sx=[-1,1], sy=[-1,1]) translate([sx*52, sy*52, -1]) cylinder(d=10.5, h=2.5, $fn=40);
    // clear the bearing opening so cables can pass
    translate([0,0,-1]) cylinder(d=B_OPEN_D-4, h=BASE_T+2, $fn=60);
  }
}
module base_placed(){ translate([0,0,-PL_T-SP_H-B_T-BASE_T+BASE_RECESS_D]) base(); }
if (PRINT) base(); else base_placed();
