// motor_mount.scad  REV 2.  DRAFT NOT MEASURED. Arch over the battery holder carrying the N20 motor, shaft up.
// Every arch part (legs, plate, socket, feet) now shares the same flat x = +ARCH_W/2 face, so the part lies on that face
// with NO supports (layers run across the arch). Longest bridge is the 10.8 mm motor bore ceiling.
// M3x8 down through each foot (head recess is open to the top, no gusset above it), M3x16 clamp screw along x.
PRINT = false;
include <params.scad>
XA = -ARCH_W/2; XB = ARCH_W/2;
module arch(){
  // plate
  translate([XA, -(LEG_IN+LEG_Y), ARCH_UNDER]) cube([ARCH_W, 2*(LEG_IN+LEG_Y), ARCH_T]);
  for (s=[-1,1]) {
    // leg
    translate([XA, s>0 ? LEG_IN : -LEG_IN-LEG_Y, BOSS_H]) cube([ARCH_W, LEG_Y, ARCH_UNDER+ARCH_T-BOSS_H]);
    // foot (x from FOOT_X0 to +ARCH_W/2, stays clear of the platform rims)
    translate([FOOT_X0, s>0 ? LEG_IN+LEG_Y : -LEG_IN-LEG_Y-FOOT_Y, BOSS_H]) cube([XB-FOOT_X0, FOOT_Y, FOOT_T]);
  }
  // motor socket block
  translate([-SOCK_X/2, -SOCK_YM, MOT_Z0]) cube([SOCK_X, SOCK_YM+SOCK_YP, SOCK_H]);
}
module motor_mount(){
  zc = MOT_Z0 + SOCK_H/2;
  difference(){
    arch();
    // motor bore
    translate([-(MOT_W+0.8)/2, -(MOT_D+0.8)/2, MOT_Z0]) cube([MOT_W+0.8, MOT_D+0.8, SOCK_H+1]);
    // tab / wire window through the plate
    translate([-4.5, -3.5, ARCH_UNDER-1]) cube([9, 7, ARCH_T+2]);
    // clamp slit through the +y wall
    translate([-SLIT/2, 0, MOT_Z0]) cube([SLIT, SOCK_YP+1, SOCK_H+1]);
    // clamp screw along x
    translate([-SOCK_X/2-1, CLAMP_Y, zc]) rotate([0,90,0]) cylinder(d=M3_CLR, h=SOCK_X+2, $fn=24);
    // head recess from the -x face
    translate([-SOCK_X/2-1, CLAMP_Y, zc]) rotate([0,90,0]) cylinder(d=M3_HEAD_D+0.8, h=HEAD_REC+1, $fn=30);
    // nut pocket from the +x face
    translate([SOCK_X/2-NUT_POCKET, CLAMP_Y, zc]) rotate([0,90,0]) hex_prism(M3_NUT_AF+NUT_SLACK, NUT_POCKET+1);
    // foot screws: through hole + head recess open to the top
    for (s=[-1,1]) translate([0, s*FOOT_SCREW_Y, 0]) {
      translate([0,0,BOSS_H-1]) cylinder(d=M3_CLR, h=ARCH_UNDER+ARCH_T, $fn=24);
      translate([0,0,BOSS_H+FOOT_T-HEAD_REC]) cylinder(d=M3_HEAD_D+0.8, h=HEAD_REC+2, $fn=30);
    }
  }
}
if (PRINT) {
  // lie on the +x face: x -> -z
  translate([0,0,ARCH_W/2]) rotate([0,90,0]) motor_mount();
} else motor_mount();
