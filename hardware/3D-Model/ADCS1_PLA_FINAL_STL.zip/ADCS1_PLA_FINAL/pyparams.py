"""Read numeric variables and the PCOMPS table straight from params.scad so the checks use the same numbers."""
import re
def load(path='params.scad'):
    t = open(path).read()
    t = re.sub(r'//.*', '', t)
    v = {}
    for m in re.finditer(r'^\s*(\w+)\s*=\s*([-\d.]+)\s*;', t, re.M):
        v[m.group(1)] = float(m.group(2))
    # simple derived values
    v['LEG_IN'] = v['BAT_D']/2 + 1.8
    v['ARCH_UNDER'] = v['BAT_H'] + v['ARCH_GAP']
    v['MOT_Z0'] = v['ARCH_UNDER'] + v['ARCH_T']
    v['MOT_TOP'] = v['MOT_Z0'] + v['MOT_L']
    v['WH_Z0'] = v['MOT_TOP'] + 1.5
    comps = []
    for m in re.finditer(r'\["(\w+)",\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),\s*([-\d.]+),\s*"([+\-xy]*)"\]', t):
        n, x, y, w, h, ht, mass, op = m.groups()
        comps.append(dict(name=n, x=float(x), y=float(y), w=float(w), h=float(h), ht=float(ht), m=float(mass), open=op))
    v['COMPS'] = comps
    return v
