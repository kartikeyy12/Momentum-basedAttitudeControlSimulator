# ADCS-1 REV 2 verification report

**Verdict: PRINTABLE WITH CONDITIONS.** Not "PRINT READY", because the bearing geometry, the motor/shaft dimensions and the M8 nut size are still unmeasured, and no slicer was available here (see section 6).

Four separate readiness statements, as requested:

| Readiness | Status |
|---|---|
| 1. Mechanical print readiness (geometry, meshes, layer analysis) | **Pass** for all 7 STLs (section 3). Conditions: section 2 measurements |
| 2. Physical assembly readiness | **Conditional**: bearing hole pattern / opening / screw-head clearance never measured; dry fit still mandatory |
| 3. Electrical safety readiness | **Not established.** No fuse, no BMS, switch rating unconfirmed, motor winding resistance unmeasured |
| 4. Operational readiness of the spinning wheel | **Not established.** Run first tests behind a shield, cover fitted, low PWM (section 5) |

## 1. Defects found in the supplied package (all verified on the real STL meshes, not on the render)

| # | Part | Defect | Evidence | Fix in REV 2 |
|---|---|---|---|---|
| C1 | flywheel | **The set screw could not work.** The grub screw hole ran from the bore, through the nut slot, straight into M8 nut pocket #6 (continuous void y = -31.3 to +1.67 at z = 5). Even before the nut is fitted a 5 mm grub screw reaches only y = -4, the shaft flat is at y = -0.8. With the nut glued in, the screw could not be reached at all | ray cast along the screw axis; slices at z = 5 | hub extended to 14 mm, screw moved above the disc into an open-top channel + open-top nut slot, wheel mounted hub-down |
| C2 | motor mount | **Arch-foot screw heads were roofed over.** At the screw axis the head recess (z 3.4-7.0) had 5 mm of gusset plastic above it (solid 7.0-12.0). The M3x8 could not be inserted or driven | vertical ray at (0, +-30.8) | gusset removed, foot 5.5 mm thick, recess open to the top. Ray now passes clear |
| C3 | motor mount | **README said "no supports"; false.** In the supplied orientation the socket block and both legs start 3-5 mm above the bed as 14-22 mm cantilevers (226 mm2 and 2 x 193 mm2 unsupported) | layer-by-layer overhang analysis | all arch parts now share one flat face (width 16 mm). Zero floating regions. Longest bridge 10.8 mm |
| C4 | motor mount | clamp nut pocket (y 5.05-10.95) and head recess broke out through the 10.5 mm outer wall and nicked the motor bore | y-rays at z = 34.5 | screw moved to y = 10.2, socket to y = 14.8. Walls now 1.65 mm outside, 1.85 mm to the bore |
| M1 | README | fastener list: M3x5 grub screw was wrong for the old hub | geometry | M3x5..8 all work with REV 2 (section 4) |
| M2 | platform holes | handoff promised slotted bearing holes, the CAD has plain 3.5 mm round holes | platform.scad | **not changed** (needs a platform rebuild). Measure the pattern, see section 2 |

Checked and found acceptable: nut pocket floors (1.2 mm = 6 layers), pocket walls (2.65 mm to the rim, 4.24 mm between pockets, 8.7 mm to the hub), watertight meshes, bed fit, platform/base/spacer/retainer geometry versus their SCAD (section 3.4).

## 2. What you must still measure before printing (unchanged from README, plus two new items)

Bearing hole pattern (82 mm?), opening (51), plate thickness, raised ring height and screw head clearance (dry fit, turn 360 deg); M8 nut AF and thickness (calipers); motor 12 x 10 x 25, shaft 3.0 D with 2.5 across flats and **length of the flat (assumed 6 mm from the tip; the screw position relies on it)**; holder size with cells fitted. A 2 mm error in the bearing hole pattern would stop the platform bolting down, and the platform has round holes.

## 3. Checks actually run (numpy/scipy only; no OpenSCAD, no trimesh, no slicer in this sandbox)

### 3.1 Mesh integrity (check_parts.py, own implementation: edge-pair closure, winding, union-find bodies)
See `check_outputs/check_parts.txt`. All 7 meshes closed, consistent winding, 1 body each (retainer: 2 intended bars). 3 zero-area filler triangles in the flywheel, 18 in the motor mount, 2 in the platform (collinear slivers from tessellation; topology closed; slicers ignore them).

### 3.2 Generation and independent verification of the changed parts
OpenSCAD is not installable here, so the three changed STLs (flywheel, motor mount, wheel cover) were built by a small Python CSG kernel (`tools/audit_scripts/csg.py`) that mirrors the new .scad files. To trust it:
* the kernel rebuilt the **original** flywheel from the original parameters: volume 21061.8 mm3 and area 12168.3 mm2, identical to the OpenSCAD STL (0.000 %);
* each new part was compared against a **separate** pixel/voxel model written directly from the parameters: flywheel 35 layers, XOR 0.00 mm2, volume +0.04 %; motor mount 12 slices XOR 0.00 mm2, volume -0.01 %.
**The STLs are therefore not OpenSCAD output.** Run `bash export_all.sh` once; check_parts must report volumes within 0.5 % of: flywheel 21.86, motor mount 10.46, cover 3.13 cm3. I could not compile the new .scad files here, only lint them (identifiers, bracket balance).

### 3.3 Layer analysis (my own, validated against analytic areas to <0.1 %; **not a slicer**)
Overhang test at 45 deg, 0.2 mm layers, in print orientation: flywheel and cover **none**; motor mount only bridges: bore ceiling 10.8 mm wide, clamp slit ceiling (1.6 mm gap, ~6 mm span), window ceiling 7 mm, small hole tops; platform, base: nut-pocket and foot-recess ceilings <= 10.5 mm. No supports needed anywhere.
Thinnest walls: 1.2 mm platform rims (3 perimeters), 1.6 mm arch socket side walls (4 perimeters), cosmetic knife edges only otherwise (hub channel cusp, 0.7 mm lip around the arch screw head recess, a rim sliver at one platform corner).

### 3.4 Unchanged parts versus their SCAD
Platform: slice areas agree with an independent re-implementation of platform.scad to <0.01 % at 8 heights; base the same; spacer volume +0.10 %; retainer 0.00 %. So the supplied STLs are current. They were only shifted to z = 0.

### 3.5 Assembly collision / clearance (check_assembly.py, voxel 0.25 mm)
No collisions among platform, base, spacers, arch, wheel, cover, motor, shaft, holder, modules, bearing, arch screws, clamp screw. Wheel hub to motor top 1.75 mm (design 1.5). Arch foot to the two nearest platform rims 0.65 mm and 1.05 mm (measured on the platform STL at z = 2.0). Arch to bubble level 1.27 mm. The checker was proven to detect faults: a 3 mm shifted arch produced "COLLISIONS FOUND". Rotation through 360 deg: rotating parts lowest z = -7 (spacers), stationary base top z = -13.8, so the 6.8 mm gap is the bearing itself; screw-head clearance inside it remains unmeasured.

### 3.6 Plates
2 plates needed (`print_plate_layout.png`): Plate 1 platform + arch + retainers + 4 spacers; Plate 2 base + flywheel + cover. All >= 5 mm from the edge and from each other.

## 4. Flywheel answers (your section 6)

| Question | Answer |
|---|---|
| Type of the 8 pockets | **Blind pockets open upward**, hex AF 13.6, floor z 0-1.2, open at the top face. Verified by ray: solid 0-1.2 at each pocket centre |
| Print with openings up | Yes, no supports, no bridging |
| 1.2 mm floor | 6 layers at 0.2 mm, boundary lies on a layer boundary; solid at 100 % infill |
| Walls | 2.65 mm to the rim (about 6 perimeters), 4.24 mm between pockets, 8.7 mm to hub |
| Nut fits | Nut 13 AF (ISO max 13.00, min 12.73) against 13.6 pocket; FDM holes print about 0.1-0.2 mm small so expect 13.4-13.5. **Weigh/measure your nuts.** Depth 6.8 mm is flush with a 6.5 mm nut and with the ISO maximum 6.8 mm |
| Retention | Radial load is carried by the pocket walls, not the glue: at 1029 rpm no-load a 5.5 g nut sees 1.6 N; wall bending stress about 0.3 MPa (PLA 40+ MPa). Glue only stops axial pop-out |
| Because the wheel now hangs hub-down the pockets face down | so axial retention matters: epoxy the nuts **and** glue on `wheel_cover.stl` (3.9 g, 1 mm). Do not rely on CA alone |
| D bore | 3.35 round, flat at 2.85 (shaft 3.0 / 2.5). Printed ~3.15-3.25 so about 0.15-0.25 mm clearance, set screw takes the play. 8 mm of shaft in a 14 mm hub. Elephant foot is at the far (bed) end beyond the shaft tip |
| Set screw reaches the flat | M3x5: tip at the flat with the nut fully engaged and 0.5 mm of screw in the channel; M3x6-8 equally fine. M3x4 marginal. Screw axis at 4.5 mm below the shaft tip (flat assumed 6 mm) |
| Set screw access | Channel and nut slot are open to the top (print) = open outward and toward the motor when mounted. Insert nut and screw while the wheel lies pockets-up, hex key goes in sideways. Key clearance to the cover about 0.75 mm |
| Does the nut slot weaken the hub | No. 18 mm hub, 5.85 mm of wall either side of the nut slot |
| Balance | Pockets symmetric; the slot/channel remove about 0.2 g at r < 8 mm, equivalent to <0.01 mm CoM offset |

## 5. Rotational safety, speed reconciliation

Measured frames per turn 28. rpm = 60 x fps / 28. fps is **still unconfirmed**.

| fps | no-load rpm | no-load rad/s | usable at 65 % | min J_w | margin (J_w = 4.46e-5) |
|---|---|---|---|---|---|
| 120 | 257 | 26.9 | 17.5 | 2.12e-5 | 2.1x |
| 240 | 514 | 53.9 | 35.0 | 1.04e-5 | 4.3x |
| 480 | 1029 | 107.7 | 70.0 | 5.2e-6 | 8.7x |

The earlier 21.6 and 35 rad/s cases are the 240 fps video at 40 % and 65 %. The 65 % figure is a judgement, not a measurement. Even the slowest reading leaves 2.1x. J_b 5.17e-4, J_w 4.46e-5 kg m2, wheel 75 g with cover, all model values that need weighing (nuts assumed 5.5 g). CoM offset 0.05 mm is **a model result only**; trim with the four pockets.
Motor torque: still unmeasured. The 29-30 mV / 1.52 mA readings (flat cells) establish nothing about winding resistance.
First spin-ups: clear acrylic or polycarbonate shield (at least 2 mm, covering the wheel plane, open top only if you also keep a hand and face out of the plane), eye protection, cover fitted, nuts epoxied and cured 24 h, tug test on every nut, start at 20 % PWM, listen for rubbing, watch the platform for vibration. Fuse (3 A) and a 3 A rocker switch before any power; firmware cut-off at 6.4 V does not replace the fuse.

## 6. What could not be established

* No slicer was available: toolpaths, perimeters and seam behaviour were **not** previewed. My layer analysis is not a substitute. Open the 7 STLs in your slicer and look at the flywheel bore, the nut pockets, the motor mount slit and bore ceiling before printing.
* The new .scad files have not been compiled. The STLs for flywheel, motor mount and cover come from the equivalent Python build.
* Bearing, motor, shaft flat, nut, holder and module dimensions are draft values. Printed hole shrinkage is a typical-value estimate; no test coupon was printed.
* Motor mount slit (1.6 mm) prints as a short bridge. If it fuses, run a knife through it. The motor is also held by the rectangular bore (it can only twist about 4 deg before wedging).
* Stiffness: hand calculation only (arch leg bending stress about 3 MPa at 5 N lateral; platform cantilever deflection 0.02 mm at 0.2 N). No FEA.
