"""Small BSP-tree CSG kernel (after csg.js) + T-junction repair + ear-clip triangulation.
Used only because OpenSCAD is not installable in this sandbox. Primitives follow OpenSCAD tessellation ($fn, start angle 0).
"""
import sys, math, struct
import numpy as np
from scipy.spatial import cKDTree
sys.setrecursionlimit(100000)
EPS = 1e-6


class Plane:
    __slots__ = ('n', 'w')

    def __init__(self, n, w):
        self.n = n; self.w = w

    @staticmethod
    def from_points(a, b, c):
        n = np.cross(b - a, c - a)
        l = np.linalg.norm(n)
        n = n / l
        return Plane(n, float(np.dot(n, a)))

    def flip(self):
        self.n = -self.n; self.w = -self.w


class Poly:
    __slots__ = ('v', 'plane')

    def __init__(self, v, plane=None):
        self.v = v
        self.plane = plane or Plane.from_points(v[0], v[1], v[2])

    def flip(self):
        self.v = self.v[::-1]; self.plane = Plane(-self.plane.n, -self.plane.w)


def split_polygon(pl, poly, cf, cb, f, b):
    COP, FRONT, BACK, SPAN = 0, 1, 2, 3
    ptype = 0; types = []
    for v in poly.v:
        t = float(np.dot(pl.n, v)) - pl.w
        ty = BACK if t < -EPS else (FRONT if t > EPS else COP)
        ptype |= ty; types.append(ty)
    if ptype == COP:
        (cf if float(np.dot(pl.n, poly.plane.n)) > 0 else cb).append(poly)
    elif ptype == FRONT:
        f.append(poly)
    elif ptype == BACK:
        b.append(poly)
    else:
        fv, bv = [], []
        n = len(poly.v)
        for i in range(n):
            j = (i + 1) % n
            ti, tj = types[i], types[j]; vi, vj = poly.v[i], poly.v[j]
            if ti != BACK: fv.append(vi)
            if ti != FRONT: bv.append(vi.copy() if ti != BACK else vi)
            if (ti | tj) == SPAN:
                t = (pl.w - float(np.dot(pl.n, vi))) / float(np.dot(pl.n, vj - vi))
                v = vi + (vj - vi) * t
                fv.append(v); bv.append(v.copy())
        if len(fv) >= 3: f.append(Poly(fv, poly.plane))
        if len(bv) >= 3: b.append(Poly(bv, poly.plane))


class Node:
    def __init__(self, polys=None):
        self.plane = None; self.front = None; self.back = None; self.polys = []
        if polys: self.build(polys)

    def invert(self):
        stack = [self]
        while stack:
            n = stack.pop()
            for p in n.polys: p.flip()
            if n.plane: n.plane.flip()
            n.front, n.back = n.back, n.front
            if n.front: stack.append(n.front)
            if n.back: stack.append(n.back)

    def clip_polys(self, polys):
        if not self.plane: return list(polys)
        f, b = [], []
        for p in polys: split_polygon(self.plane, p, f, b, f, b)
        if self.front: f = self.front.clip_polys(f)
        b = self.back.clip_polys(b) if self.back else []
        return f + b

    def clip_to(self, bsp):
        self.polys = bsp.clip_polys(self.polys)
        if self.front: self.front.clip_to(bsp)
        if self.back: self.back.clip_to(bsp)

    def all_polys(self):
        out = list(self.polys)
        if self.front: out += self.front.all_polys()
        if self.back: out += self.back.all_polys()
        return out

    def build(self, polys):
        if not polys: return
        if not self.plane:
            p0 = polys[len(polys) // 2].plane
            self.plane = Plane(p0.n.copy(), p0.w)
        f, b = [], []
        for p in polys: split_polygon(self.plane, p, self.polys, self.polys, f, b)
        if f:
            if not self.front: self.front = Node()
            self.front.build(f)
        if b:
            if not self.back: self.back = Node()
            self.back.build(b)


class Solid:
    def __init__(self, polys): self.polys = polys

    def clone(self): return Solid([Poly([v.copy() for v in p.v], Plane(p.plane.n.copy(), p.plane.w)) for p in self.polys])

    def union(self, o):
        a = Node(self.clone().polys); b = Node(o.clone().polys)
        a.clip_to(b); b.clip_to(a); b.invert(); b.clip_to(a); b.invert()
        a.build(b.all_polys()); return Solid(a.all_polys())

    def subtract(self, o):
        a = Node(self.clone().polys); b = Node(o.clone().polys)
        a.invert(); a.clip_to(b); b.clip_to(a); b.invert(); b.clip_to(a); b.invert()
        a.build(b.all_polys()); a.invert(); return Solid(a.all_polys())

    def intersect(self, o):
        a = Node(self.clone().polys); b = Node(o.clone().polys)
        a.invert(); b.clip_to(a); b.invert(); a.clip_to(b); b.clip_to(a)
        a.build(b.all_polys()); a.invert(); return Solid(a.all_polys())

    def transform(self, M):  # M 4x4
        R = M[:3, :3]; t = M[:3, 3]
        out = []
        for p in self.polys:
            v = [R @ x + t for x in p.v]
            out.append(Poly(v))
        if np.linalg.det(R) < 0:
            for p in out: p.flip()
        return Solid(out)


def _P(v): return np.array(v, float)


def prism_from_ring(ring, z0, z1):
    """ring: CCW list of (x,y) convex polygon -> prism along z."""
    n = len(ring); polys = []
    bot = [_P((x, y, z0)) for x, y in ring]; top = [_P((x, y, z1)) for x, y in ring]
    polys.append(Poly(bot[::-1])); polys.append(Poly(top))
    for i in range(n):
        j = (i + 1) % n
        polys.append(Poly([bot[i], bot[j], top[j], top[i]]))
    return Solid(polys)


def box(x0, x1, y0, y1, z0, z1):
    return prism_from_ring([(x0, y0), (x1, y0), (x1, y1), (x0, y1)], z0, z1)


def cyl(r, z0, z1, n, cx=0.0, cy=0.0, rot=0.0, d=None):
    if d is not None: r = d / 2
    ring = [(cx + r * math.cos(math.radians(rot) + 2 * math.pi * i / n), cy + r * math.sin(math.radians(rot) + 2 * math.pi * i / n)) for i in range(n)]
    return prism_from_ring(ring, z0, z1)


def hexprism(af, z0, z1, cx=0.0, cy=0.0, rot=0.0):
    return cyl(af / math.cos(math.radians(30)) / 2, z0, z1, 6, cx, cy, rot)


def rotx(a):
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1]], float)


def roty(a):
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    return np.array([[c, 0, s, 0], [0, 1, 0, 0], [-s, 0, c, 0], [0, 0, 0, 1]], float)


def rotz(a):
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1]], float)


def trans(x, y, z):
    M = np.eye(4); M[:3, 3] = (x, y, z); return M


# ------------------------------------------------------------------ mesh output
def _tjunction_fix(polys, tol=1e-5):
    pts = np.array([v for p in polys for v in p.v])
    key = np.round(pts / tol).astype(np.int64)
    uniq, idx, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
    V = pts[idx]
    inv = inv.ravel()
    faces = []; k = 0
    for p in polys:
        faces.append(list(inv[k:k + len(p.v)])); k += len(p.v)
    tree = cKDTree(V)
    out = []
    for f in faces:
        # drop consecutive duplicates
        g = [f[i] for i in range(len(f)) if f[i] != f[(i + 1) % len(f)]]
        if len(g) < 3: continue
        newf = []
        for i in range(len(g)):
            a, b = g[i], g[(i + 1) % len(g)]
            newf.append(a)
            A, B = V[a], V[b]; L = np.linalg.norm(B - A)
            if L < 2 * tol: continue
            cand = tree.query_ball_point((A + B) / 2, L / 2 + tol)
            ins = []
            for c in cand:
                if c in (a, b): continue
                t = float(np.dot(V[c] - A, B - A) / L ** 2)
                if 1e-9 < t < 1 - 1e-9 and np.linalg.norm(A + t * (B - A) - V[c]) < 5 * tol:
                    ins.append((t, c))
            ins.sort()
            newf += [c for _, c in ins]
        out.append(newf)
    return V, out


def _earclip(V, f, normal):
    ax = np.argmax(np.abs(normal)); idx = [i for i in range(3) if i != ax]
    sign = 1 if normal[ax] > 0 else -1
    P = [(V[i][idx[0]], V[i][idx[1]] * sign) for i in f]
    n = len(f); ids = list(range(n)); tris = []
    def cross(o, a, b): return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])
    guard = 0
    while len(ids) > 3 and guard < 100000:
        guard += 1; clipped = False
        m = len(ids)
        for k in range(m):
            i0, i1, i2 = ids[k - 1], ids[k], ids[(k + 1) % m]
            c = cross(P[i0], P[i1], P[i2])
            if c <= 1e-9: continue
            ok = True
            for j in ids:
                if j in (i0, i1, i2): continue
                if cross(P[i0], P[i1], P[j]) >= -1e-12 and cross(P[i1], P[i2], P[j]) >= -1e-12 and cross(P[i2], P[i0], P[j]) >= -1e-12:
                    ok = False; break
            if ok:
                tris.append((f[i0], f[i1], f[i2])); ids.pop(k); clipped = True; break
        if not clipped:  # fall back: clip flattest vertex
            k = 0; tris.append((f[ids[k - 1]], f[ids[k]], f[ids[(k + 1) % len(ids)]])); ids.pop(k)
    if len(ids) == 3: tris.append((f[ids[0]], f[ids[1]], f[ids[2]]))
    return tris


def to_triangles(solid):
    polys = [p for p in solid.polys if len(p.v) >= 3]
    V, faces = _tjunction_fix(polys)
    tris = []
    for p, f in zip(polys, faces):
        if len(f) == 3: tris.append(tuple(f))
        else: tris += _earclip(V, f, p.plane.n)
    T = np.array([[V[a], V[b], V[c]] for a, b, c in tris])
    # remove zero-area (keep topology otherwise)
    return T


def write_stl(path, tri, name='part'):
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    l = np.linalg.norm(n, axis=1); l[l == 0] = 1
    n = n / l[:, None]
    with open(path, 'wb') as fh:
        fh.write((name.encode() + b' ' * 80)[:80]); fh.write(struct.pack('<I', len(tri)))
        rec = np.zeros(len(tri), dtype=np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')]))
        rec['n'] = n; rec['v'] = tri; fh.write(rec.tobytes())


def clean_mesh(T, tol=1e-5):
    """Remove zero-area triangles by splitting the neighbour across the long edge (collinear sliver collapse),
    then re-weld. Falls back to keeping the sliver if topology would break."""
    from collections import defaultdict
    for _ in range(6):
        flat = T.reshape(-1, 3); key = np.round(flat / tol).astype(np.int64)
        uniq, idx, inv = np.unique(key, axis=0, return_index=True, return_inverse=True)
        V = flat[idx]; F = inv.ravel().reshape(-1, 3).tolist()
        area = lambda f: 0.5 * np.linalg.norm(np.cross(V[f[1]] - V[f[0]], V[f[2]] - V[f[0]]))
        deg = [i for i, f in enumerate(F) if len(set(f)) < 3 or area(f) < 1e-7]
        if not deg: break
        edge_faces = defaultdict(list)
        for i, f in enumerate(F):
            for k in range(3): edge_faces[(f[k], f[(k + 1) % 3])].append(i)
        remove = set(); add = []
        for i in deg:
            f = F[i]
            if len(set(f)) < 3: remove.add(i); continue
            # long edge = the one whose midpoint-vertex lies on it
            L = [np.linalg.norm(V[f[(k + 1) % 3]] - V[f[k]]) for k in range(3)]
            k = int(np.argmax(L)); a, b, m = f[k], f[(k + 1) % 3], f[(k + 2) % 3]
            # neighbour across directed edge (b,a)
            nb = [j for j in edge_faces.get((b, a), []) if j != i and j not in remove]
            if len(nb) != 1: continue
            j = nb[0]; g = F[j]
            # find the third vertex of neighbour
            c = [x for x in g if x not in (a, b)]
            if len(c) != 1: continue
            c = c[0]
            # replace neighbour (b,a,c)-oriented by two triangles split at m
            # neighbour has directed edge b->a ; orient: (b,a,c) cyc
            kk = [t for t in range(3) if g[t] == b and g[(t + 1) % 3] == a]
            if not kk: continue
            remove.add(i); remove.add(j)
            add.append((b, m, c)); add.append((m, a, c))
        if not remove: break
        F = [f for i, f in enumerate(F) if i not in remove] + [list(t) for t in add]
        T = np.array([[V[a], V[b], V[c]] for a, b, c in F])
    return T
