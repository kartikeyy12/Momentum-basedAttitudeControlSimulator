import sys, pickle, numpy as np, shutil, os
sys.path.insert(0,'.')
from csg import *
from meshlib import *
from build_new import P
raw=pickle.load(open('new_raw.pkl','rb'))
def xf(T,M):
    R=M[:3,:3];t=M[:3,3]; Q=T.reshape(-1,3)@R.T+t; Q=Q.reshape(-1,3,3)
    if np.linalg.det(R)<0: Q=Q[:,::-1]
    return Q
def dropz(T): T=T.copy(); T[:,:,2]-=T[:,:,2].min(); return T
D='final/stl'; os.makedirs(D+'/placed',exist_ok=True)
# ---- motor mount: print frame = lie on +x face
mm=raw['motor_mount']; mmp=xf(mm,trans(0,0,P['ARCH_W']/2)@roty(90)); mmp[:,:,0]-=mmp[:,:,0].min(); mmp=dropz(mmp)
write_stl(f'{D}/motor_mount.stl',mmp,'motor_mount'); write_stl(f'{D}/placed/motor_mount.stl',mm,'motor_mount_placed')
# ---- flywheel: print frame = disc on bed hub up ; placed = flipped, hub down, hub end at WH_Z0
fw=raw['flywheel']; write_stl(f'{D}/flywheel.stl',fw,'flywheel')
M=trans(0,0,P['WH_Z0']+P['WH_HUB_H'])@rotx(180); write_stl(f'{D}/placed/flywheel.stl',xf(fw,M),'flywheel_placed')
cv=raw['wheel_cover']; write_stl(f'{D}/wheel_cover.stl',cv,'wheel_cover')
# placed cover: pocket face of disc is at mount z = WH_Z0+HUB_H-WH_T ; cover sits under it
zc=P['WH_Z0']+P['WH_HUB_H']-P['WH_T']-P['COVER_T']
write_stl(f'{D}/placed/wheel_cover.stl',xf(cv,trans(0,0,zc)),'wheel_cover_placed')
# ---- unchanged parts copied from the supplied package (dropped to z=0 for printing only)
for n in ('platform','base','spacer','battery_retainer'):
    t=load_stl(f'adcs1_cad/stl/{n}.stl'); write_stl(f'{D}/{n}.stl',dropz(t),n)
    t=load_stl(f'adcs1_cad/stl/placed/{n}.stl'); write_stl(f'{D}/placed/{n}.stl',t,n+'_placed')
print("exported",sorted(os.listdir(D)))
