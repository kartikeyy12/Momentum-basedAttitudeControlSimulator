"""Independent Python build of the CORRECTED parts (mirrors the corrected .scad files; OpenSCAD itself is not installable in this sandbox)."""
import sys, math, time, numpy as np
sys.path.insert(0,'.')
from csg import *
from meshlib import *

# ---------------- corrected parameters (mirror params.scad)
P=dict(
 M3_CLR=3.5, M3_NUT_AF=5.5, M3_NUT_T=2.4, NUT_SLACK=0.4, NUT_POCKET=2.8, M3_HEAD_D=5.8, M3_HEAD_H=2.6,
 BOSS_H=1.5, BAT_D=40, BAT_H=21, ARCH_GAP=2.5, ARCH_T=4, LEG_Y=5, FOOT_Y=8,
 MOT_W=12, MOT_D=10, MOT_L=25, MOT_SHAFT=9.5, MOT_SHAFT_D=3, MOT_FLAT=2.5,
 NUT_AF=13, NUT_TH=6.5, N_NUTS=8, WH_RING_R=24.5, WH_R=34.2, WH_T=8, WH_HUB_D=18, WH_POCKET=13.6, SHAFT_CLR=0.35,
 # corrected / new
 ARCH_W=16, FOOT_X0=-7, FOOT_T=5.5, SOCK_X=16, SOCK_YM=8, SOCK_YP=14.8, SOCK_H=14, CLAMP_Y=10.2, SLIT=1.6, HEAD_REC=3.0,
 WH_HUB_H=14, SCREW_ABOVE_DISC=2.5, CH_W=3.6, COVER_D=66, COVER_T=1.0, COVER_HOLE=19.2,
)
P['LEG_IN']=P['BAT_D']/2+1.8; P['ARCH_UNDER']=P['BAT_H']+P['ARCH_GAP']
P['FOOT_SCREW_Y']=P['LEG_IN']+P['LEG_Y']+P['FOOT_Y']/2
P['MOT_Z0']=P['ARCH_UNDER']+P['ARCH_T']; P['MOT_TOP']=P['MOT_Z0']+P['MOT_L']; P['WH_Z0']=P['MOT_TOP']+1.5
g=lambda k:P[k]

def flywheel():
    R,T,HD,HH=g('WH_R'),g('WH_T'),g('WH_HUB_D'),g('WH_HUB_H')
    s=cyl(R,0,T,120).union(cyl(HD/2,0.5,HH,60))
    for i in range(g('N_NUTS')):
        a=i*360/g('N_NUTS'); cx,cy=g('WH_RING_R')*math.cos(math.radians(a)),g('WH_RING_R')*math.sin(math.radians(a))
        z0=T-g('NUT_TH')-0.3
        s=s.subtract(hexprism(g('WH_POCKET'),z0,z0+g('NUT_TH')+1,cx,cy,rot=a+30))
    d=g('MOT_SHAFT_D')+g('SHAFT_CLR'); flat=g('MOT_FLAT')+g('SHAFT_CLR')
    dh=cyl(0,-1,HH+1,48,d=d).intersect(box(-d,d,d/2-flat,d/2-flat+2*d,-1,HH+1))
    s=s.subtract(dh)
    zs=T+g('SCREW_ABOVE_DISC')                       # set-screw axis height (above the disc face)
    nw=g('M3_NUT_AF')+g('NUT_SLACK')+0.4; nd=g('M3_NUT_T')+0.4; ny0=2.5
    # screw channel: open-top slot along -y from the bore flat to outside the hub
    s=s.subtract(box(-g('CH_W')/2,g('CH_W')/2,-(HD/2+1),-0.9,zs-1.8,HH+1))
    # nut slot: open top
    s=s.subtract(box(-nw/2,nw/2,-(ny0+nd),-ny0,zs-3.5,HH+1))
    return s
def wheel_cover():
    return cyl(g('COVER_D')/2,0,g('COVER_T'),120).subtract(cyl(g('COVER_HOLE')/2,-1,g('COVER_T')+1,60))

def motor_mount():
    W=g('ARCH_W'); xa,xb=-W/2,W/2; LI,LY,FY=g('LEG_IN'),g('LEG_Y'),g('FOOT_Y'); BH=g('BOSS_H')
    top=g('ARCH_UNDER')+g('ARCH_T')
    parts=[box(xa,xb,-(LI+LY+0),(LI+LY),g('ARCH_UNDER'),top)]
    for sgn in (1,-1):
        y0,y1=(LI,LI+LY) if sgn>0 else (-LI-LY,-LI)
        parts.append(box(xa,xb,y0,y1,BH,top))
        fy0,fy1=(LI+LY,LI+LY+FY) if sgn>0 else (-LI-LY-FY,-LI-LY)
        parts.append(box(g('FOOT_X0'),xb,fy0,fy1,BH,BH+g('FOOT_T')))
    parts.append(box(-g('SOCK_X')/2,g('SOCK_X')/2,-g('SOCK_YM'),g('SOCK_YP'),g('MOT_Z0'),g('MOT_Z0')+g('SOCK_H')))
    s=parts[0]
    for p in parts[1:]: s=s.union(p)
    Z0=g('MOT_Z0'); H=g('SOCK_H')
    s=s.subtract(box(-(g('MOT_W')+0.8)/2,(g('MOT_W')+0.8)/2,-(g('MOT_D')+0.8)/2,(g('MOT_D')+0.8)/2,Z0,Z0+H+1))      # motor bore
    s=s.subtract(box(-4.5,4.5,-3.5,3.5,g('ARCH_UNDER')-1,g('ARCH_UNDER')+g('ARCH_T')+1))                          # tab window
    s=s.subtract(box(-g('SLIT')/2,g('SLIT')/2,0,g('SOCK_YP')+1,Z0,Z0+H+1))                                         # clamp slit
    zc=Z0+H/2; yc=g('CLAMP_Y'); SX=g('SOCK_X')/2
    s=s.subtract(cyl(0,-SX-1,SX+1,24,d=g('M3_CLR')).transform(trans(0,yc,zc)@roty(90)))                             # screw hole (axis x)
    s=s.subtract(cyl(0,0,g('HEAD_REC')+1,30,d=g('M3_HEAD_D')+0.8).transform(trans(-SX-1,yc,zc)@roty(90)))            # head recess from -x face
    s=s.subtract(hexprism(g('M3_NUT_AF')+g('NUT_SLACK'),0,g('NUT_POCKET')+1).transform(trans(SX-g('NUT_POCKET'),yc,zc)@roty(90)))  # nut pocket from +x face
    for sgn in (1,-1):
        fy=sgn*g('FOOT_SCREW_Y')
        s=s.subtract(cyl(0,BH-1,top+1,24,cx=0,cy=fy,d=g('M3_CLR')))
        s=s.subtract(cyl(0,BH+g('FOOT_T')-g('HEAD_REC'),BH+g('FOOT_T')+2,30,cx=0,cy=fy,d=g('M3_HEAD_D')+0.8))
    return s
def mm_print(s):   # lie on the +x face: x -> -z, then drop to z=0 ; also move x>=0
    return s.transform(trans(0,0,g('ARCH_W')/2)@roty(90))

def save(name,solid,placed_solid=None,print_solid=None):
    T=to_triangles(solid)
    return T
if __name__=='__main__':
    out={}
    for name,fn in (('flywheel',flywheel),('wheel_cover',wheel_cover),('motor_mount',motor_mount)):
        t0=time.time(); s=fn(); T=to_triangles(s); r=integrity(T)
        print(f"{name:12s} built {time.time()-t0:5.1f}s tris={r['tris']} wt={r['watertight']} open={r['open_edges']} nm={r['nonmanifold_edges']} wind={r['inconsistent_winding_edges']} deg={r['degenerate']} comps={r['components']} vol={r['volume']:.1f} size={(r['bbox_max']-r['bbox_min']).round(2)}")
        out[name]=(s,T)
    import pickle; pickle.dump({k:v[1] for k,v in out.items()},open('new_raw.pkl','wb'))
