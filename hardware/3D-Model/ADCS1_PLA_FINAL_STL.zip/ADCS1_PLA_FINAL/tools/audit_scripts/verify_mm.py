import sys, math, pickle, numpy as np
sys.path.insert(0,'.')
from meshlib import *
from build_new import P
g=lambda k:P[k]
T=raw=pickle.load(open('new_raw.pkl','rb'))['motor_mount']   # ASSEMBLY frame (z up from platform top)
res=0.1
xs=np.arange(-9,9,res)+res/2; ys=np.arange(-36,36,res)+res/2; zs=np.arange(0,43,res)+res/2
X,Y,Z=np.meshgrid(xs,ys,zs,indexing='ij')
def pm(U,V,cu,cv,R,n,rot):
    a=np.radians(rot)+2*np.pi*np.arange(n)/n; px=cu+R*np.cos(a); py=cv+R*np.sin(a); m=np.ones(U.shape,bool)
    for i in range(n):
        j=(i+1)%n; m&=((px[j]-px[i])*(V-py[i])-(py[j]-py[i])*(U-px[i]))>=0
    return m
W=g('ARCH_W');LI,LY,FY,BH=g('LEG_IN'),g('LEG_Y'),g('FOOT_Y'),g('BOSS_H');top=g('ARCH_UNDER')+g('ARCH_T')
def inbox(x0,x1,y0,y1,z0,z1): return (X>=x0)&(X<=x1)&(Y>=y0)&(Y<=y1)&(Z>=z0)&(Z<=z1)
M=inbox(-W/2,W/2,-(LI+LY),LI+LY,g('ARCH_UNDER'),top)
for s in (1,-1):
    y0,y1=(LI,LI+LY) if s>0 else (-LI-LY,-LI); M|=inbox(-W/2,W/2,y0,y1,BH,top)
    fy0,fy1=(LI+LY,LI+LY+FY) if s>0 else (-LI-LY-FY,-LI-LY); M|=inbox(g('FOOT_X0'),W/2,fy0,fy1,BH,BH+g('FOOT_T'))
M|=inbox(-8,8,-g('SOCK_YM'),g('SOCK_YP'),g('MOT_Z0'),g('MOT_Z0')+g('SOCK_H'))
Z0=g('MOT_Z0');H=g('SOCK_H')
M&=~inbox(-6.4,6.4,-5.4,5.4,Z0,Z0+H+1); M&=~inbox(-4.5,4.5,-3.5,3.5,g('ARCH_UNDER')-1,top+1)
M&=~inbox(-g('SLIT')/2,g('SLIT')/2,0,g('SOCK_YP')+1,Z0,Z0+H+1)
zc=Z0+H/2; yc=g('CLAMP_Y')
M&=~(pm(Y,Z,yc,zc,g('M3_CLR')/2,24,-90))                                   # through x
M&=~(pm(Y,Z,yc,zc,(g('M3_HEAD_D')+0.8)/2,30,-90)&(X<=-8-1+g('HEAD_REC')+1))
M&=~(pm(Y,Z,yc,zc,(g('M3_NUT_AF')+g('NUT_SLACK'))/math.cos(math.radians(30))/2,6,90)&(X>=8-g('NUT_POCKET')))
for s in (1,-1):
    fy=s*g('FOOT_SCREW_Y')
    M&=~(pm(X,Y,0,fy,g('M3_CLR')/2,24,0)&(Z>=BH-1))
    M&=~(pm(X,Y,0,fy,(g('M3_HEAD_D')+0.8)/2,30,0)&(Z>=BH+g('FOOT_T')-g('HEAD_REC')))
vm=M.sum()*res**3; vi=integrity(T)['volume']
print(f"MOTOR MOUNT: mask volume {vm:.0f} mm3 vs mesh {vi:.0f} mm3 ({100*(vm/vi-1):+.2f}%)")
worst=0; zlist=[2,3.5,5,6.5,12,24,25.5,28,30,34.5,38,41]
b=((-9,-36),(9,36))
for z in zlist:
    img=raster_fill(T,z+0.013,res,b)
    k=int(round((z+0.013-zs[0])/res)); mk=M[:,:,k].T   # [y,x]
    x=(img[:mk.shape[0],:mk.shape[1]]^mk).sum()*res*res; worst=max(worst,x)
    print(f"   z={z:5.1f}: mesh area {img.sum()*res*res:7.1f}  mask area {mk.sum()*res*res:7.1f}  xor {x:5.2f} mm2")
print("MOTOR MOUNT max slice XOR:",round(worst,2),"mm2")
print("\nPROBES (assembly frame):")
def show(l,o,a):
    h,iv=solid_intervals(T,o,a); print(f"  {l:58s}",[(round(p,2),round(q,2)) for p,q in iv] if iv else 'none/odd')
show("foot screw axis (+y) z-ray at (0.01,30.8)",(0.01,30.8,0),'z')
show("foot screw head recess edge (2.5,30.8)",(2.5,30.8,0),'z')
show("foot screw axis (-y) z-ray",(0.01,-30.8,0),'z')
show("clamp nut pocket: y-ray at x=7.0,z=34.5",(7.0,0,34.5),'y')
show("clamp head recess: y-ray at x=-7.0,z=34.5",(-7.0,0,34.5),'y')
show("clamp screw axis x-ray at y=10.2,z=34.5",(0,10.2,34.5),'x')
show("bore/ear wall y-ray at x=3,z=34.5",(3.0,0,34.5),'y')
show("pocket wall to outer face: y-ray x=7,z=31.5(pocket corner)",(7.0,0,31.5),'y')
