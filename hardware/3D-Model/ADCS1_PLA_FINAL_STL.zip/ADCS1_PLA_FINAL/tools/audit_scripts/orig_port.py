import sys, math, time, numpy as np
sys.path.insert(0,'.')
from csg import *
from meshlib import *
from pyparams import load
P=load('adcs1_cad/params.scad')
g=lambda k:P[k]
M3_CLR=g('M3_CLR');M3_NUT_AF=g('M3_NUT_AF');M3_NUT_T=g('M3_NUT_T');NUT_SLACK=g('NUT_SLACK');NUT_POCKET=g('NUT_POCKET')
M3_HEAD_D=g('M3_HEAD_D');M3_HEAD_H=g('M3_HEAD_H')
def orig_flywheel():
    WH_R,WH_T,HUB_D,HUB_H=g('WH_R'),g('WH_T'),g('WH_HUB_D'),g('WH_HUB_H')
    s=cyl(WH_R,0,WH_T,120).union(cyl(HUB_D/2,0.5,HUB_H,60))
    for i in range(int(g('N_NUTS'))):
        a=i*360/g('N_NUTS')
        cx,cy=g('WH_RING_R')*math.cos(math.radians(a)),g('WH_RING_R')*math.sin(math.radians(a))
        s=s.subtract(hexprism(g('WH_POCKET'),WH_T-g('NUT_TH')-0.3,WH_T-g('NUT_TH')-0.3+g('NUT_TH')+1,cx,cy,rot=a+30))
    d=g('MOT_SHAFT_D')+g('SHAFT_CLR'); flat=g('MOT_FLAT')+g('SHAFT_CLR')
    dh=cyl(0,-1,HUB_H+1,48,d=d).intersect(box(-d,d,d/2-flat,d/2-flat+2*d,-1,HUB_H+1))
    s=s.subtract(dh)
    # screw tunnel along -y at z=5: cylinder d=M3_CLR-0.1 h=HUB_D
    tun=cyl(0,0,HUB_D,24,d=M3_CLR-0.1).transform(trans(0,0,5)@rotx(90))  # rotate([90,0,0]) -> z to -y
    s=s.subtract(tun)
    slot=box(-(M3_NUT_AF+NUT_SLACK)/2-0.2,-(M3_NUT_AF+NUT_SLACK)/2-0.2+M3_NUT_AF+NUT_SLACK+0.4,
             -(4.2+M3_NUT_T+0.4),-(4.2+M3_NUT_T+0.4)+M3_NUT_T+0.4, 5-(M3_NUT_AF+NUT_SLACK)/2, 5-(M3_NUT_AF+NUT_SLACK)/2+HUB_H)
    s=s.subtract(slot)
    return s
if __name__=='__main__':
    t0=time.time(); s=orig_flywheel(); T=to_triangles(s); print("built in %.1fs"%(time.time()-t0))
    r=integrity(T); ref=integrity(load_stl('adcs1_cad/stl/flywheel.stl'))
    print("mine : vol %.1f area %.1f tris %d watertight=%s open=%d deg=%d comps=%d bbox %s"%(r['volume'],r['area'],r['tris'],r['watertight'],r['open_edges'],r['degenerate'],r['components'],(r['bbox_max']-r['bbox_min']).round(2)))
    print("openscad: vol %.1f area %.1f tris %d"%(ref['volume'],ref['area'],ref['tris']))
    print("volume diff %.3f%%  area diff %.3f%%"%(100*(r['volume']/ref['volume']-1),100*(r['area']/ref['area']-1)))
