import sys, math, pickle, numpy as np
sys.path.insert(0,'.')
from meshlib import *
from build_new import P
g=lambda k:P[k]
raw=pickle.load(open('new_raw.pkl','rb'))
def poly_mask(X,Y,cx,cy,R,n,rot=0.0):
    ang=np.radians(rot)+2*np.pi*np.arange(n)/n
    px=cx+R*np.cos(ang); py=cy+R*np.sin(ang)
    m=np.ones(X.shape,bool)
    for i in range(n):
        j=(i+1)%n; ex,ey=px[j]-px[i],py[j]-py[i]
        m&=(ex*(Y-py[i])-ey*(X-px[i]))>=0
    return m
# ---------- flywheel
res=0.1; b=((-36,-36),(36,36)); xs=-36+(np.arange(720)+0.5)*res; X,Y=np.meshgrid(xs,xs)
def fly_mask(z):
    R,T,HD,HH=g('WH_R'),g('WH_T'),g('WH_HUB_D'),g('WH_HUB_H')
    m=poly_mask(X,Y,0,0,R,120) if z<T else np.zeros(X.shape,bool)
    if z<HH: m|=poly_mask(X,Y,0,0,HD/2,60)
    if z>T-g('NUT_TH')-0.3:
        for i in range(g('N_NUTS')):
            a=i*360/g('N_NUTS'); cx,cy=g('WH_RING_R')*math.cos(math.radians(a)),g('WH_RING_R')*math.sin(math.radians(a))
            m&=~poly_mask(X,Y,cx,cy,g('WH_POCKET')/math.cos(math.radians(30))/2,6,a+30)
    d=g('MOT_SHAFT_D')+g('SHAFT_CLR'); flat=g('MOT_FLAT')+g('SHAFT_CLR')
    m&=~(poly_mask(X,Y,0,0,d/2,48)&(Y>=d/2-flat))
    zs=T+g('SCREW_ABOVE_DISC'); nw=g('M3_NUT_AF')+g('NUT_SLACK')+0.4; nd=g('M3_NUT_T')+0.4
    if z>=zs-1.8: m&=~((np.abs(X)<=g('CH_W')/2)&(Y>=-(HD/2+1))&(Y<=-0.9))
    if z>=zs-3.5: m&=~((np.abs(X)<=nw/2)&(Y>=-(2.5+nd))&(Y<=-2.5))
    return m
T=raw['flywheel']; worst=0; vol_m=0
for z in np.arange(0.1,14,0.4):
    img=raster_fill(T,z+0.013,res,b); mk=fly_mask(z+0.013)
    x=(img^mk).sum()*res*res; worst=max(worst,x)
print(f"FLYWHEEL: max XOR area between mesh slice and independent mask over 35 layers = {worst:.2f} mm2 (slice area ~2300-3700 mm2)")
# mask volume
vm=sum(fly_mask(z+0.013).sum()*res*res*0.2 for z in np.arange(0.1,14,0.2))
print(f"FLYWHEEL: mask volume {vm:.0f} mm3 vs mesh volume {integrity(T)['volume']:.0f} mm3 ({100*(vm/integrity(T)['volume']-1):+.2f}%)")
# ---------- probes on flywheel (print frame)
zs=g('WH_T')+g('SCREW_ABOVE_DISC')
h,iv=solid_intervals(T,(0.0001,-20,zs),'y'); print("FLYWHEEL ray along y at x=0, z=%.1f (screw axis): solid intervals:"%zs,[(round(a,2),round(b,2)) for a,b in iv])
h,iv=solid_intervals(T,(0.0001,-20,zs+1.6),'y'); print("   same at z+1.6 (above screw)               :",[(round(a,2),round(b,2)) for a,b in iv])
h,iv=solid_intervals(T,(0.0001,-20,9.0),'y'); print("   same at z=9.0                             :",[(round(a,2),round(b,2)) for a,b in iv])
h,iv=solid_intervals(T,(0.0001,-24.5,0),'z'); print("   pocket #6 floor ray along z at (0,-24.5)  :",[(round(a,2),round(b,2)) for a,b in iv])
# vertical rays through hub top to check slot is open to the top
for (x,y,l) in ((0,-3.9,'nut slot centre'),(0,-7.0,'channel outside nut slot'),(0,5,'hub solid +y')):
    h,iv=solid_intervals(T,(x+1e-4,y,0),'z'); print(f"   z-ray {l:26s}:",[(round(a,2),round(b,2)) for a,b in iv])
