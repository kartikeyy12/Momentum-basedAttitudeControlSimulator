import sys, math, numpy as np
sys.path.insert(0,'.')
from meshlib import *
from pyparams import load
P=load('adcs1_cad/params.scad'); g=lambda k:P[k]
res=0.1
def grid(x0,x1,y0,y1):
    xs=np.arange(x0,x1,res)+res/2; ys=np.arange(y0,y1,res)+res/2; return np.meshgrid(xs,ys)
def rect(X,Y,cx,cy,w,h): return (np.abs(X-cx)<=w/2)&(np.abs(Y-cy)<=h/2)
def rrect(X,Y,w,h,r):
    ix=np.clip(np.abs(X),0,w/2-r); iy=np.clip(np.abs(Y),0,h/2-r); return (np.hypot(np.abs(X)-ix,np.abs(Y)-iy)<=r)
def circ(X,Y,cx,cy,r): return (X-cx)**2+(Y-cy)**2<=r*r
def hexm(X,Y,cx,cy,af):
    m=np.ones(X.shape,bool)
    for k in range(6):
        a=math.radians(60*k); m&=((X-cx)*math.cos(a)+(Y-cy)*math.sin(a))<=af/2
    return m   # flats at 0,60.. = same as cylinder $fn=6 rotated 30deg? (checked below via both orientations)
CL,RW=g('CL'),g('RIM_W'); comps=P['COMPS']
X,Y=grid(-81,81,-68,68)
def cav(c,extra=0): return rect(X,Y,c['x'],c['y'],c['w']+2*(CL+extra),c['h']+2*(CL+extra))
def opn(c):
    s=c['open']
    if s=='+y': return rect(X,Y,c['x'],c['y']+c['h']/2+CL+RW/2,c['w']+2*CL,RW+2)
    if s=='-y': return rect(X,Y,c['x'],c['y']-c['h']/2-CL-RW/2,c['w']+2*CL,RW+2)
    return np.zeros(X.shape,bool)
BX,BY,BW=g('BAL_X'),g('BAL_Y'),g('BAL_W')
FY=g('LEG_IN')+g('LEG_Y')+g('FOOT_Y')/2
rimadd=np.zeros(X.shape,bool); rimsub=np.zeros(X.shape,bool)
for c in comps: rimadd|=cav(c,RW); rimsub|=cav(c)|opn(c)
rimadd|=rect(X,Y,BX,BY,BW+2*(CL+1.6),BW+2*(CL+1.6))
for s in (-1,1): rimadd|=rect(X,Y,s*(g('BAT_W')/2+1.5+g('BAT_END_WALL')/2),0,g('BAT_END_WALL'),34)
rimsub|=rect(X,Y,BX,BY,BW+2*CL,BW+2*CL)
for s in (-1,1): rimsub|=rect(X,Y,0,s*FY,g('LEG_X')+1,g('FOOT_Y')+1)
rim=rimadd&~rimsub&~rect(X,Y,BX,BY,0.01,0.01)
out=rrect(X,Y,g('PL_X'),g('PL_Y'),g('PL_R'))
tall=out&rect(X,Y,BX,BY,BW+2*(CL+1.6),BW+2*(CL+1.6))&~rect(X,Y,BX,BY,BW+2*CL,BW+2*CL)
def pf(z):
    m=np.zeros(X.shape,bool)
    if -3<=z<=0: m|=out
    if 0<=z<=g('RIM_H'): m|=rim&out
    if 0<=z<=6: m|=tall
    pads=np.zeros(X.shape,bool)
    for sx in (-1,1):
        for sy in (-1,1): pads|=rect(X,Y,sx*g('B_HOLE_P'),sy*g('B_HOLE_P'),g('BOSS_W'),g('BOSS_W'))
    for s in (-1,1): pads|=rect(X,Y,0,s*FY,g('LEG_X'),g('FOOT_Y'))
    if -3<=z<=g('BOSS_H'): m|=pads
    cut=np.zeros(X.shape,bool)
    for sx in (-1,1):
        for sy in (-1,1):
            cx,cy=sx*g('B_HOLE_P'),sy*g('B_HOLE_P')
            if -4<=z<=2.5: cut|=circ(X,Y,cx,cy,g('M3_CLR')/2)
            if g('BOSS_H')-g('NUT_POCKET')<=z<=g('BOSS_H')+1: cut|=HEX(cx,cy)
    for s in (-1,1):
        cx,cy=0,s*FY
        if -4<=z<=2.5: cut|=circ(X,Y,cx,cy,g('M3_CLR')/2)
        if -4<=z<=-4+g('NUT_POCKET')+1: cut|=HEX(cx,cy)
    for sx in (-1,1):
        for sy in (-1,1):
            if -4<=z<=5.5: cut|=rect(X,Y,sx*g('RB_X'),sy*g('TIE_Y'),g('TIE_SLOT_X'),g('TIE_SLOT_Y'))
            if -g('TRIM_DEPTH')<=z<=1: cut|=circ(X,Y,sx*g('TRIM_X'),sy*g('TRIM_Y'),g('TRIM_D')/2)
    return m&~cut
AF=g('M3_NUT_AF')+g('NUT_SLACK')
def HEXrot(cx,cy,rot):
    R=AF/math.cos(math.radians(30))/2; m=np.ones(X.shape,bool)
    for k in range(6):
        a=math.radians(rot+60*k+30); m&=((X-cx)*math.cos(a)+(Y-cy)*math.sin(a))<=AF/2
    return m
HEX=lambda cx,cy: HEXrot(cx,cy,0)   # cylinder $fn=6 has vertices at 0deg => flats at 30deg+60k
T=load_stl('adcs1_cad/stl/placed/platform.stl')
b=((-81,-68),(81,68)); worst=0
for z in (-2.0,-1.0,-0.5,0.8,1.3,2.0,3.0,5.5):
    img=raster_fill(T,z+0.013,res,b); mk=pf(z+0.013)
    n=min(img.shape[0],mk.shape[0]),min(img.shape[1],mk.shape[1])
    x=(img[:n[0],:n[1]]^mk[:n[0],:n[1]]).sum()*res*res
    worst=max(worst,x); print(f"platform z={z:5.1f}: mesh {img.sum()*res*res:8.1f} mm2  independent SCAD-mask {mk.sum()*res*res:8.1f} mm2  xor {x:6.2f} mm2")
print("platform worst xor:",round(worst,2),"mm2 (outline corner tessellation of offset(r) accounts for a few tenths)")
# base / spacer / retainer
Tb=load_stl('adcs1_cad/stl/base.stl'); Xb,Yb=grid(-61,61,-61,61)
def bm(z):
    X_,Y_=Xb,Yb
    m=np.zeros(X_.shape,bool)
    m=rrect(X_,Y_,g('BASE_X'),g('BASE_Y'),g('BASE_R'))
    if z>=g('BASE_T')-g('BASE_RECESS_D'): m&=~rect(X_,Y_,0,0,g('BASE_RECESS'),g('BASE_RECESS'))
    for sx in (-1,1):
        for sy in (-1,1):
            m&=~circ(X_,Y_,sx*g('B_HOLE_P'),sy*g('B_HOLE_P'),g('M3_CLR')/2)
            if z<=-1+g('NUT_POCKET')+1:
                R=AF/math.cos(math.radians(30))/2; hm=np.ones(X_.shape,bool)
                for k in range(6):
                    a=math.radians(60*k+30); hm&=((X_-sx*g('B_HOLE_P'))*math.cos(a)+(Y_-sy*g('B_HOLE_P'))*math.sin(a))<=AF/2
                m&=~hm
            if z<=1.5: m&=~circ(X_,Y_,sx*52,sy*52,5.25)
    m&=~circ(X_,Y_,0,0,(g('B_OPEN_D')-4)/2)
    return m
for z in (0.3,1.0,2.0,3.5,5.5):
    img=raster_fill(Tb,z+0.013,res,((-61,-61),(61,61))); mk=bm(z+0.013)
    print(f"base z={z}: mesh {img.sum()*res*res:8.1f} mask {mk.sum()*res*res:8.1f} xor {(img^mk).sum()*res*res:6.2f}")
for n,vol in (('spacer',4*(g('SP_W')**2*g('SP_H')-math.pi*(g('M3_CLR')/2)**2*g('SP_H'))),('battery_retainer',2*(g('RB_W')*g('RB_L')*g('RB_T')-g('TIE_GROOVE')*g('RB_L')*1.2))):
    v=integrity(load_stl(f'adcs1_cad/stl/{n}.stl'))['volume']*(4 if n=='spacer' else 1)
    if n=='spacer': v=integrity(load_stl('adcs1_cad/stl/spacer.stl'))['volume']*4
    print(f"{n}: STL volume x qty {v:.1f} mm3 vs analytic from params {vol:.1f} mm3 ({100*(v/vol-1):+.2f}%)")
