import sys, numpy as np
sys.path.insert(0,'.')
from meshlib import *
from scipy import ndimage as ndi

def layers(tri, h=0.2, res=0.25):
    mn=tri.reshape(-1,3).min(0); mx=tri.reshape(-1,3).max(0)
    n=int(np.floor((mx[2]-mn[2])/h+1e-6))
    bounds=((mn[0]-1,mn[1]-1),(mx[0]+1,mx[1]+1))
    out=[]
    for i in range(n):
        z=mn[2]+(i+0.5)*h
        img=raster_fill(tri,z+0.013,res,bounds); x0,y0,r=bounds[0][0],bounds[0][1],res
        out.append(img)
    return out,(bounds[0][0],bounds[0][1],res,mn[2],h)

def disk(r):
    y,x=np.ogrid[-r:r+1,-r:r+1]; return x*x+y*y<=r*r

def analyse(name, tri, h=0.2, res=0.25, angle_deg=45, min_area=3.0):
    L,(x0,y0,r,z0,h)=layers(tri,h,res)
    shift=h*np.tan(np.radians(angle_deg))   # allowed horizontal growth per layer
    k=max(1,int(round(shift/r)))
    st=disk(k)
    flagged=[]
    for i in range(1,len(L)):
        sup=ndi.binary_dilation(L[i-1],structure=st)
        oh=L[i]&~sup
        lab,n=ndi.label(oh)
        for j in range(1,n+1):
            comp=lab==j
            a=comp.sum()*r*r
            if a>=min_area:
                edt=ndi.distance_transform_edt(comp)*r
                width=2*edt.max()
                ys,xs=np.where(comp)
                # does comp touch supported material on >=2 sides? crude: ratio of perimeter adjacent to support
                ring=ndi.binary_dilation(comp,structure=disk(2))&~comp
                touch=(ring&L[i-1]).sum()/max(1,ring.sum())
                flagged.append((z0+(i+0.5)*h-h/2, a, width, x0+xs.mean()*r, y0+ys.mean()*r, touch))
    # merge by layer
    print(f"--- {name}: {len(L)} layers, bbox z {z0:.1f}..{z0+len(L)*h:.1f}; unsupported regions (>=45deg overhang, >{min_area} mm2):")
    if not flagged: print("    none"); return
    # group consecutive layers
    byz={}
    for f in flagged: byz.setdefault(round(f[0],1),[]).append(f)
    zs=sorted(byz)
    for zz in zs[:6]:
        for f in byz[zz][:4]:
            print(f"    z={zz:5.1f} area={f[1]:7.1f} mm2 width~{f[2]:5.1f} mm at xy=({f[3]:6.1f},{f[4]:6.1f}) support-contact={f[5]:.2f}")
    tot=sum(f[1] for f in flagged)
    print(f"    total flagged layer-area {tot:.0f} mm2 over {len(zs)} layers; worst width {max(f[2] for f in flagged):.1f} mm at z={max(flagged,key=lambda f:f[2])[0]:.1f}")

if __name__=='__main__':
    names=sys.argv[1:] or ['flywheel','spacer','battery_retainer','base','motor_mount','platform']
    for n in names:
        tri=load_stl(f'{STLDIR}/{n}.stl')
        analyse(n,tri)
