import sys, numpy as np
sys.path.insert(0,'.')
from meshlib import *
from scipy import ndimage as ndi
from skimage.morphology import skeletonize
res=0.1
def minwall(name, T, zstep=0.8):
    mn=T.reshape(-1,3).min(0); mx=T.reshape(-1,3).max(0)
    b=((mn[0]-1,mn[1]-1),(mx[0]+1,mx[1]+1)); best=(99,None)
    for z in np.arange(mn[2]+0.3,mx[2],zstep):
        img=raster_fill(T,z+0.013,res,b)
        if not img.any(): continue
        edt=ndi.distance_transform_edt(img)*res
        sk=skeletonize(img)
        # ignore skeleton points near junction ends: take 5th percentile of 2*edt on the skeleton (robust) and absolute min
        vals=2*edt[sk]
        vals=vals[vals>0.5]
        if len(vals)==0: continue
        m=np.percentile(vals,1)
        if m<best[0]:
            iy,ix=np.where(sk&(2*edt<=m+1e-9)); best=(m,(z,b[0][0]+ix[0]*res,b[0][1]+iy[0]*res))
    return best
for n in ['flywheel','wheel_cover','motor_mount','platform','base','spacer','battery_retainer']:
    T=load_stl(f'final/stl/{n}.stl')
    m,loc=minwall(n,T)
    print(f"{n:17s} thinnest wall (1st percentile of skeleton thickness over sampled layers) = {m:4.2f} mm at z={loc[0]:.1f} xy=({loc[1]:.1f},{loc[2]:.1f})")
