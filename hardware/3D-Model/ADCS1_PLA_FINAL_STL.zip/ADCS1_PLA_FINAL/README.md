# ADCS-1 mechanical design, REV 2 (PLA, Ender 3 class)  Verdict: PRINTABLE WITH CONDITIONS

Read `verification_report.md` first. REV 2 fixes four real defects found in the previous package (set screw unusable, arch screw heads roofed over, arch needed unmentioned supports, clamp pocket broke through its wall). **Nothing here has been printed or fit-checked.** Dimensions marked DRAFT in `params.scad` are still unmeasured.

## 1. What changed from the earlier package
| part | change |
|---|---|
| `flywheel.stl` | hub 14 mm, **mounted upside down (hub down onto the shaft, pockets facing down)**. M3 set screw and nut sit in open-top channel/slot in the hub, above the disc |
| `wheel_cover.stl` | **new**, flat disc glued over the pockets after the nuts are glued in. Recommended |
| `motor_mount.stl` | width 16 mm everywhere, prints on its side **with no supports**; gusset removed so foot screws are reachable; clamp ear moved out so the nut pocket stays inside the wall |
| platform, base, spacer, battery_retainer | unchanged (verified against their SCAD). STLs only shifted to z = 0 |

## 2. Before you print (all DRAFT NOT MEASURED)
1. Bearing: hole pattern `B_HOLE_P` (82 mm?), opening, plate thickness, raised ring. The platform has round 3.5 mm holes, so a pattern error above about 0.5 mm means the platform will not bolt down. Measure it.
2. M8 nut AF and thickness, motor 12 x 10 x 25, shaft 3.0 mm with D flat, **flat length (assumed 6 mm)**, holder size with cells, module sizes. Weigh the nuts.
3. Open all STLs in your slicer and look at the layers (no slicer was available when this was made).
4. Run `bash export_all.sh` if you have OpenSCAD: it rebuilds all STLs from the .scad files and the checks. The flywheel, motor mount and cover STLs supplied here were built by an equivalent Python model (see report 3.2).

## 3. Printed parts
| file | qty | orientation (as in the STL) | supports | walls / infill | est. mass | volume cm3 |
|---|---|---|---|---|---|---|
| `platform.stl` | 1 | top face up, flat | no | 3 / 20-25 % | 38 g | 67.6 |
| `base.stl` | 1 | flat | no | 3 / 20-25 % | 37 g | 65.6 |
| `motor_mount.stl` | 1 | **already lying on its side, do not rotate** | **no** (longest bridge 10.8 mm) | 4 / 40-50 % | 8 g | 10.46 |
| `flywheel.stl` | 1 | pockets up, hub up | no | 4 / **100 %** | 27 g | 21.86 |
| `wheel_cover.stl` | 1 (recommended) | flat | no | 100 % | 4 g | 3.13 |
| `spacer.stl` | 4 | flat | no | 100 % | 0.6 g each | 0.45 |
| `battery_retainer.stl` | 1 (file has 2 bars) | flat | no | 100 % | 2 g | 1.67 |
PLA, 0.4 nozzle, 0.2 layers, 2 build plates (`print_plate_layout.png`). Slow outer walls on the flywheel (30 mm/s), full cooling for the motor mount bridges. Do not turn supports on. Weigh the flywheel and the arch; put real masses in `params.scad`.

**Do not drill or enlarge printed holes to make a fit.** Compensation already built in: round holes +0.5 (M3 3.5), D bore +0.35, M8 pocket AF 13.6 for a 13 nut, M3 nut pockets AF 5.9 for 5.5. If an M8 nut will not go in, file the pocket corners with a small file; if the arch motor bore is tight, use a file, not a drill. If the 1.6 mm clamp slit fused, cut it with a knife.

## 4. Fasteners and other items
| item | qty | where |
|---|---|---|
| M3 x 10 | 4 (+4) | platform to bearing top plate (unchanged) |
| M3 x 6 | 4 (+4) | base to bearing bottom plate (unchanged) |
| M3 x 8 | 2 | arch feet; tip ends about 1 mm below the platform. Needs 1 mm free there. M3 x 6 also works (1.8 mm in the nut) |
| M3 x 16 | 1 | motor clamp, head in the -x recess, nut in the +x pocket |
| M3 grub / set screw 5 to 8 mm | 2 | wheel hub. 5 mm works, 6 to 8 mm is easier |
| M3 nut | 12 | bearing 4, base 4, arch 2, clamp 1, set screw 1 |
| M8 steel nut | 8 (+2 to 3 ballast) | wheel |
| epoxy (5 min is fine, 24 h cure) | | M8 nuts. CA alone is not recommended |
| cable ties 2.5 mm, 150 mm | 4 | battery bars |
| rubber feet 10 mm | 4 | base |
| 3 A rocker switch, 3 A fuse/PTC | 1 each | battery path |
| 100 k + 47 k resistors | 1 each | battery divider |

## 5. Assembly order
1. Dry fit M3 screws in the bearing and turn the top plate through 360 deg.
2. **Wheel**: lay it pockets-up. Epoxy the 8 M8 nuts in. Cure 24 h. Tug every nut. Glue `wheel_cover.stl` over the pockets (cover face against the pocket face, hub through the hole).
3. Still pockets-up: drop an M3 nut into the slot, start the set screw into it from the channel side, back it out until the tip does not enter the bore.
4. Base: push 4 M3 nuts into the underside pockets, sit the bearing in the recess, turn the plate 45 deg, fit 4 base screws, turn back.
5. Platform: 4 M3 nuts into the corner pads, 2 into the pockets under the arch pads (tape holds them). 4 spacers, platform on top, 4 screws from below.
6. Arch: 2 x M3 x 8 down through the feet (the head recesses are open, use a screwdriver from above).
7. Modules into their pockets with foam tape, solder, nano USB and antenna to the open rim side.
8. Slide the holder under the arch from the end, fit the two bars and cable ties.
9. Motor: tabs through the window, body into the socket, tighten the clamp screw.
10. **Wheel on the shaft, turned upside down**: hub end down, rotate until the D flat lines up and it slides on. The hub end stops about 1.5 mm above the motor. Turn the set screw onto the flat with a hex key sideways through the open channel.
11. Balance and bring up (section 7).

## 6. CoM and inertia (model values; weigh the real parts)
`python3 com_table.py` (see `check_outputs/com_table.txt`): total 383 g, CoM offset 0.05 mm (model only), J_b 5.17e-4, J_w 4.46e-5 kg m2, wheel 75 g. Margins 2.1x to 8.7x depending on the video frame rate (unconfirmed). Details in report section 5.

## 7. Balance and bring-up
1. Table level (bubble pad). 2. Turn the platform to 4 or more angles and let go. If it always drifts the same way, tape washers into the trim pockets on the opposite side. 3. Spin the wheel by hand: no rubbing, no wobble. 4. Fit the shield, eye protection, power with fuse at low PWM. 5. Measure pack voltage, motor resistance and no-load speed, update `params.scad`.

## 8. Safety
Wheel carries 44 g of steel. Never run it unshielded, never lean over it, keep hair and sleeves clear. Fuse and a 3 A rocker before any power. Do not charge a cell that sat below about 2 V. A firmware cutoff is not an overcurrent protection.

## 9. Files
`params.scad` all numbers. `platform.scad base.scad spacer.scad battery_retainer.scad motor_mount.scad flywheel.scad wheel_cover.scad assembly.scad` parts. `export_all.sh`, `check_parts.py`, `check_assembly.py`, `com_table.py`, `pyparams.py`, `meshlib.py` checks (numpy/scipy only). `render_views.py`, `print_plate_layout.py`. `stl/` print files, `stl/placed/` assembly-position files. `tools/audit_scripts/` the scripts used for the audit (csg kernel, independent mask checks, overhang and wall analysis) exactly as run; paths refer to the sandbox. `check_outputs/` output of the shipped checks.
